/* ============================================================
 * 完工成本 / 利润快照取数链（任务v36）
 * 背景：finance.calcOrderProfit 锁定不可动，且对 v35.1「线缆敷设」行名
 *      双向 includes 均不中（客户费按总量全额错算、成本映射不中计 0）。
 *      本模块不走该链：完工时直接调用本模块算材料成本与利润快照，
 *      由调用方写入 completion.profitData（statistics 三级链吃快照不重算）。
 * 红线：与客户收费无关——电缆按总量全额进成本；
 * 依赖铁则：本模块禁止 import storage（成本映射/材料库由调用方读取后传入，
 *      与 finance.ts / costMapping.ts 同一规则，保证纯函数可测）
 * ============================================================ */

import type {
  CostMapping,
  FixedAuxSelection,
  MaterialItem,
} from "@/types";
import { FIXED_AUX_MATERIALS, queryCostPrice } from "@/lib/costMapping";
import { calcMaterialCost } from "@/lib/finance";
import { calcFixedAuxCostV2 } from "@/lib/fixedAux";

/* ------------------------------------------------------------
 * 一、兜底常量
 * ------------------------------------------------------------ */

/** 电缆进价兜底（元/米）：映射未命中时使用，对齐 DEFAULT_COST_MAPPINGS 电缆=18 */
export const CABLE_COST_FALLBACK = 18;

/** PVC 管进价兜底（元/米）：映射未命中时使用，对齐 DEFAULT_COST_MAPPINGS PVC管=3.5 */
export const PVC_COST_FALLBACK = 3.5;

/** 电缆总量行名（v35.1 完工物料行）：电缆成本由 cableTotalMeters 全额计，
 *  该行从增项映射成本中剔除，防重复计成本 */
const CABLE_TOTAL_ROW_NAME = "线缆敷设";

/** 金额保留两位小数（与 finance.round2 同口径，分位防浮点） */
function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/* ------------------------------------------------------------
 * 二、完工材料成本
 * ------------------------------------------------------------ */

/** calcCompletionMaterialCost 入参 */
export interface CompletionMaterialCostParams {
  /** 完工增项物料清单（含「线缆敷设」总量行，该行自动剔除防重计） */
  materials: MaterialItem[];
  /** 电缆总量（米）：全额计成本，与客户是否超米收费无关 */
  cableTotalMeters: number;
  /** 增项→成本映射（调用方 loadCostMappings() 读取后传入） */
  mappings: CostMapping[];
  /** 固定辅材选择（Order.fixedAux 快照取值源；无值按 FIXED_AUX_MATERIALS 原样一份） */
  fixedAux?: FixedAuxSelection;
}

/** 材料成本拆解（任务v36.1 FAIL-5：预估到手可溯源，电缆/固定辅材/其他三类必拆） */
export interface CompletionMaterialCostDetail {
  /** 合计 = cable + other + fixedAux（分位防浮点） */
  total: number;
  /** 电缆全额成本（cableTotalMeters × 映射"电缆"进价，未命中兜底 18） */
  cable: number;
  /** 固定辅材（fixedAux 快照按 V2 算 / 无值按 FIXED_AUX_MATERIALS 原样一份） */
  fixedAux: number;
  /** 其他增项映射成本（非「线缆敷设」行，finance.calcMaterialCost 口径） */
  other: number;
}

/**
 * 完工材料成本拆解 =
 *   电缆全额成本（cableTotalMeters × queryCostPrice("电缆")，未命中兜底 18）
 * + 增项映射成本（非「线缆敷设」行，复用 finance.calcMaterialCost 口径）
 * + 固定辅材（fixedAux 有值→calcFixedAuxCostV2(sel, PVC映射价兜底 3.5)；
 *             无值→FIXED_AUX_MATERIALS 原样一份 76）
 */
export function calcCompletionMaterialCostDetail(
  params: CompletionMaterialCostParams,
): CompletionMaterialCostDetail {
  const { materials, cableTotalMeters, mappings, fixedAux } = params;

  /* 1. 电缆全额成本（套包内也计成本，与客户收费口径无关） */
  const cableUnitPrice =
    queryCostPrice("电缆", mappings) || CABLE_COST_FALLBACK;
  const cable = round2(cableTotalMeters * cableUnitPrice);

  /* 2. 非「线缆敷设」行的增项映射成本（未命中映射计 0，与 finance 同口径） */
  const addonRows = materials.filter(
    (m) => !m.name.includes(CABLE_TOTAL_ROW_NAME),
  );
  const { total: otherCost } = calcMaterialCost(addonRows, mappings);

  /* 3. 固定辅材：有快照取值源按 V2 算，无值按 FIXED_AUX_MATERIALS 原样一份 */
  const auxCost = fixedAux
    ? calcFixedAuxCostV2(
        fixedAux,
        queryCostPrice("PVC管", mappings) || PVC_COST_FALLBACK,
      )
    : FIXED_AUX_MATERIALS.reduce(
        (sum, item) => sum + (item.unitPrice ?? 0) * item.quantity,
        0,
      );

  return {
    total: round2(cable + otherCost + auxCost),
    cable,
    fixedAux: round2(auxCost),
    other: round2(otherCost),
  };
}

/** 完工材料成本合计（= calcCompletionMaterialCostDetail(...).total；
 *  签名与 v36 口径不变，内部复用 detail 防双份逻辑漂移） */
export function calcCompletionMaterialCost(
  params: CompletionMaterialCostParams,
): number {
  return calcCompletionMaterialCostDetail(params).total;
}

/* ------------------------------------------------------------
 * 三、完工利润快照
 * ------------------------------------------------------------ */

/** buildCompletionProfitData 入参 */
export interface CompletionProfitParams {
  /** 服务费/结算费（元，不扣点） */
  serviceFee: number;
  /** 客户实收（元；未改=应收合计由调用方兜底传入） */
  actualReceived: number;
  /** 平台扣点率（小数，0.10 = 10%） */
  platformRate: number;
  /** 材料成本（元，calcCompletionMaterialCost 结果） */
  materialCost: number;
}

/** 完工利润快照（platformDeduction 供 CompletionInfo 同名字段写入；
 *  其余四字段与 ProfitSnapshot 对齐） */
export interface CompletionProfitData {
  /** 结算费（= serviceFee，不扣点） */
  baseFee: number;
  /** 客户实收（= actualReceived） */
  customerPaid: number;
  /** 平台扣点金额（元）：round2(实收 × 扣点率) */
  platformDeduction: number;
  /** 材料成本（元，原样返回入参） */
  materialCost: number;
  /** 利润（元）：round2(实收 − 扣点 + 服务费 − 材料成本) */
  profit: number;
}

/**
 * 完工利润快照：customerPaid=实收；platformDeduction=round2(实收×扣点率)；
 * profit=round2(实收 − 扣点 + 服务费 − 材料成本)
 */
export function buildCompletionProfitData(
  params: CompletionProfitParams,
): CompletionProfitData {
  const { serviceFee, actualReceived, platformRate, materialCost } = params;
  const platformDeduction = round2(actualReceived * platformRate);
  return {
    baseFee: serviceFee,
    customerPaid: actualReceived,
    platformDeduction,
    materialCost,
    profit: round2(actualReceived - platformDeduction + serviceFee - materialCost),
  };
}
