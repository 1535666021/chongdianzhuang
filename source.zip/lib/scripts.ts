/* ============================================================
 * 话术模板层：场景/变量清单 + 默认品牌话术 + 模板渲染
 * 规范：话术模板数据与渲染逻辑只此一处，
 *      页面/组件经 storage.ts 读取模板后调用本模块纯函数渲染
 * 依赖铁则：本模块禁止 import storage（storage.ts → scripts.ts 单向，
 *      DEFAULT_BRAND_SCRIPTS 由 storage 单向引用，与 costMapping 同模式）
 * ============================================================ */

import type { BrandScript, Order, ScriptScene } from "@/types";

/* ------------------------------------------------------------
 * 一、场景与变量清单（SettingsPage 展示/编辑用）
 * ------------------------------------------------------------ */

/** 话术场景清单（顺序即展示顺序） */
export const SCRIPT_SCENES: { key: ScriptScene; label: string }[] = [
  { key: "preVisit", label: "上门前" },
  { key: "surveyComplete", label: "勘测完成" },
  { key: "installComplete", label: "安装完成" },
];

/** 模板可用变量清单（SettingsPage 变量提示展示用，书写格式 {key}） */
export const SCRIPT_VARIABLES: { key: string; label: string }[] = [
  { key: "customerName", label: "客户姓名" },
  { key: "address", label: "地址" },
  { key: "cableDistance", label: "电缆距离" },
  { key: "materials", label: "物料清单" },
  { key: "totalCost", label: "预估费用" },
  { key: "installerName", label: "安装师傅" },
  { key: "brandName", label: "品牌" },
  { key: "appointmentDate", label: "预约日期" },
  { key: "timeSlot", label: "时段" },
];

/* ------------------------------------------------------------
 * 二、默认品牌话术
 * ------------------------------------------------------------ */

/** 默认品牌话术（用户未配置时 storage 层回退用，SettingsPage 可改；"default" 为其他品牌兜底） */
export const DEFAULT_BRAND_SCRIPTS: BrandScript[] = [
  {
    brandId: "lixiang",
    scene: "preVisit",
    content:
      "您好 {customerName}，我是理想充电桩安装师傅{installerName}，已预约 {appointmentDate} {timeSlot} 上门安装（地址：{address}）。请提前确认车位可正常进出，电表箱钥匙备好，有事随时联系我。",
  },
  {
    brandId: "lixiang",
    scene: "surveyComplete",
    content:
      "您好 {customerName}，您家电表到桩位距离约 {cableDistance} 米，勘测已完成。预估物料：{materials}，预估费用 {totalCost}。确认无误后我们将尽快为您安排安装。",
  },
  {
    brandId: "lixiang",
    scene: "installComplete",
    content:
      "您好 {customerName}，您的理想充电桩已安装完成并验收。使用物料：{materials}。如有任何使用问题欢迎随时联系，祝您用车愉快！",
  },
  {
    brandId: "default",
    scene: "surveyComplete",
    content:
      "您好 {customerName}，现场勘测已完成，电表到桩位约 {cableDistance} 米。预估物料：{materials}，预估费用 {totalCost}，确认后安排安装。",
  },
  {
    brandId: "default",
    scene: "installComplete",
    content:
      "您好 {customerName}，充电桩安装已完成。使用物料：{materials}。有问题随时联系。",
  },
];

/* ------------------------------------------------------------
 * 三、模板渲染与变量构造（纯函数，不读存储）
 * ------------------------------------------------------------ */

/** 变量替换：{key} → vars[key]，未知变量原样保留 */
export function renderScript(
  template: string,
  vars: Record<string, string>,
): string {
  return template.replace(/\{(\w+)\}/g, (raw, key: string) =>
    key in vars ? vars[key] : raw,
  );
}

/**
 * 从订单构造变量表（缺省值一律给空字符串，不得抛错）：
 * - customerName / address 取自订单；brandName 取订单 brandId（订单只存品牌 ID）
 * - cableDistance 优先 extras（表单未保存值），回退 survey?.cableDistance；appointmentDate / timeSlot 取 appointment
 * - installerName 优先取 extras.installerName（表单实际值），缺省回退 appointment?.installer
 * - materials / totalCost 由调用方传入 extras.materialsText（多行明细）/ extras.totalCostText
 */
export function buildScriptVars(
  order: Order,
  extras?: {
    materialsText?: string;
    totalCostText?: string;
    installerName?: string;
    /** 表单内尚未保存的电缆距离（勘测提交前场景），优先于 survey.cableDistance */
    cableDistance?: number;
  },
): Record<string, string> {
  return {
    customerName: order.customerName ?? "",
    address: order.address ?? "",
    brandName: order.brandId ?? "",
    cableDistance:
      extras?.cableDistance != null
        ? String(extras.cableDistance)
        : order.survey?.cableDistance != null
          ? String(order.survey.cableDistance)
          : "",
    appointmentDate: order.appointment?.appointmentDate ?? "",
    timeSlot: order.appointment?.timeSlot ?? "",
    installerName: extras?.installerName ?? order.appointment?.installer ?? "",
    materials: extras?.materialsText ?? "",
    totalCost: extras?.totalCostText ?? "",
  };
}

/** 取模板：精确匹配 brandId+scene；无则回退 brandId==="default"+scene；再无则返回空字符串 */
export function getScript(
  brandId: string,
  scene: ScriptScene,
  scripts: BrandScript[],
): string {
  const exact = scripts.find(
    (s) => s.brandId === brandId && s.scene === scene,
  );
  if (exact) return exact.content;
  const fallback = scripts.find(
    (s) => s.brandId === "default" && s.scene === scene,
  );
  return fallback?.content ?? "";
}
