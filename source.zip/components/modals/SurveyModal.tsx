/* ============================================================
 * 勘测登记弹窗
 * 内含并导出 MaterialListEditor（完工弹窗仍在复用，该组件本身保持不动；
 * 勘测表单的增项区按任务R改为本文件内的"下拉选择"实现——
 * 选项来自 getAddonOptions（品牌增项清单按历史使用频率降序），
 * 选中后带出售单价为默认金额，可增可删可改金额）
 * 任务R：分区卡片（线缆信息 / 位置信息）+ 卡内双列网格（标签在上控件在下）；
 *      打开即全预设：勘测人=设置页工程师姓名（engineerName 联动）、
 *      勘测日期=当天，取电方式/线缆规格/勘测详情/电表状态/
 *      物业需要施工方案图/勘测结果 读 loadFormPresets()；
 *      电缆距离输入实时显示"预估增项"（套包米数/超米单价读品牌费率配置）
 * ============================================================ */

import { useEffect, useMemo, useState } from "react";
import { Modal } from "@/components/common/Modal";
import { FormField } from "@/components/common/FormField";
import { ScriptDialog } from "@/components/ScriptDialog";
import { useApp } from "@/context/AppContext";
import {
  findBrand,
  getBrandMaterialPack,
  mergeBrands,
} from "@/lib/brandMaterials";
import { getAddonOptions } from "@/lib/addonOptions";
/* 任务v33：零跑增项触发判定与金额计算（业务逻辑收敛 lib，本组件只渲染） */
import {
  isLeapmotorBrand,
  leapmotorAddonLineAmount,
  leapmotorAddonsTotal,
} from "@/lib/leapmotorAddons";
/* 任务v35：套包米数识别 / 增项「线缆敷设」行同步与话术行文本（业务逻辑收敛 lib，本组件只渲染） */
import {
  buildCableOverFeeText,
  CABLE_ADDON_ROW_NAME,
  parsePackageMetersFromText,
  syncCableAddonRow,
} from "@/lib/packageMeters";
import { TextPreviewDialog } from "@/components/TextPreviewDialog";
import { getScript } from "@/lib/scripts";
import {
  loadBrandScripts,
  loadCostMappings,
  loadFormPresets,
  loadLeapmotorAddons,
  loadMaterialsLib,
  loadRateConfigs,
} from "@/lib/storage";
import { materialNames } from "@/lib/materials";
import { todayStr } from "@/lib/utils";
import type { MaterialItem, SurveyModalProps } from "@/types";

/* ------------------------------------------------------------
 * 物料清单编辑器（导出供 CompleteModal 复用，保持原实现不动）
 * ------------------------------------------------------------ */
export interface MaterialListEditorProps {
  items: MaterialItem[];
  onChange: (items: MaterialItem[]) => void;
}

const EMPTY_MATERIAL: MaterialItem = {
  name: "",
  spec: "",
  quantity: 1,
  unit: "个",
};

export function MaterialListEditor({ items, onChange }: MaterialListEditorProps) {
  const { orders } = useApp();

  /* 增项名称联想：按历史订单物料使用频率降序（同频保持映射表原顺序）。
   * 仅提供候选，选中后不回填 unitPrice（单价是客户价，由师傅定） */
  const nameOptions = useMemo(() => {
    const freq = new Map<string, number>();
    for (const order of orders) {
      const used = [
        ...(order.survey?.materials ?? []),
        ...(order.completion?.materials ?? []),
      ];
      for (const m of used) {
        freq.set(m.name, (freq.get(m.name) ?? 0) + 1);
      }
    }
    const fromMappings = loadCostMappings().map((m) => m.addonName);
    /* 任务D：候选 = 成本映射增项 ∪ 材料库名称（去重），按使用频率降序、同频按来源顺序 */
    const fromLib = materialNames(loadMaterialsLib());
    const all = [...new Set([...fromMappings, ...fromLib])];
    return all
      .map((name, index) => ({ name, index, count: freq.get(name) ?? 0 }))
      .sort((a, b) => b.count - a.count || a.index - b.index)
      .map((entry) => entry.name);
  }, [orders]);

  const patchItem = (
    index: number,
    key: keyof MaterialItem,
    value: string,
  ) => {
    const next = items.map((item, i) => {
      if (i !== index) return item;
      if (key === "quantity" || key === "unitPrice") {
        const num = Number(value);
        return { ...item, [key]: Number.isFinite(num) ? num : 0 };
      }
      return { ...item, [key]: value };
    });
    onChange(next);
  };

  const removeItem = (index: number) => {
    onChange(items.filter((_, i) => i !== index));
  };

  const addItem = () => {
    onChange([...items, { ...EMPTY_MATERIAL }]);
  };

  return (
    <div className="flex-column gap-sm">
      {/* 增项候选（按使用频率降序），勘测/完工两弹窗共用此 datalist */}
      <datalist id="material-name-options">
        {nameOptions.map((name) => (
          <option key={name} value={name} />
        ))}
      </datalist>
      {items.map((item, index) => (
        <div key={index} className="card card--flat">
          <div className="flex gap-sm">
            <input
              className="input flex-1"
              placeholder="物料名称"
              list="material-name-options"
              value={item.name}
              onChange={(e) => patchItem(index, "name", e.target.value)}
            />
            <button
              type="button"
              className="btn btn--danger-outline btn--sm"
              aria-label="删除物料"
              onClick={() => removeItem(index)}
            >
              删
            </button>
          </div>
          <div className="flex gap-sm mt-sm">
            <input
              className="input flex-1"
              placeholder="规格"
              value={item.spec}
              onChange={(e) => patchItem(index, "spec", e.target.value)}
            />
            <input
              className="input flex-1"
              type="number"
              inputMode="decimal"
              min="0"
              placeholder="数量"
              value={String(item.quantity)}
              onChange={(e) => patchItem(index, "quantity", e.target.value)}
            />
            <input
              className="input flex-1"
              placeholder="单位"
              value={item.unit}
              onChange={(e) => patchItem(index, "unit", e.target.value)}
            />
          </div>
        </div>
      ))}
      <button
        type="button"
        className="btn btn--secondary btn--sm"
        onClick={addItem}
      >
        ＋ 添加物料
      </button>
    </div>
  );
}

/* ------------------------------------------------------------
 * 勘测弹窗主体
 * ------------------------------------------------------------ */
interface SurveyErrors {
  surveyDate?: string;
  surveyor?: string;
  cableDistance?: string;
}

/**
 * 超米预估缺省回退链（任务R：禁硬编码数字字面量，缺省集中在此并注释）：
 * 优先读设置页「费率配置」该品牌的 packageMeters / overMeterPrice，
 * 未配置时回退到下列缺省（与话术 buildScriptVars 的缺省口径一致）
 */
const FALLBACK_PACKAGE_METERS = 30; // 套包米数缺省（米）
const FALLBACK_OVER_METER_PRICE = 45; // 超米单价缺省（元/米）

export function SurveyModal({ open, order, onClose }: SurveyModalProps) {
  const { settings, customBrands, orders, saveSurvey, showToast, updateOrder } =
    useApp();

  const [surveyDate, setSurveyDate] = useState(todayStr());
  const [surveyor, setSurveyor] = useState("");
  const [cableDistance, setCableDistance] = useState("30");
  /* 任务v35：套包米数（字符串态输入；保存时有值才持久化到 order.packageMeters） */
  const [packageMetersInput, setPackageMetersInput] = useState("");
  const [note, setNote] = useState("");
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [errors, setErrors] = useState<SurveyErrors>({});
  /** 勘测完成话术弹窗开关（保存勘测校验通过后先弹话术） */
  const [scriptOpen, setScriptOpen] = useState(false);
  /** 任务v35：预估清单外发预览弹窗开关（复制前一律先弹预览，v35 总规矩） */
  const [estimatePreviewOpen, setEstimatePreviewOpen] = useState(false);
  /* 任务Q 话术变量可选字段（不强制填写，缺省话术对应变量为空） */
  const [powerSource, setPowerSource] = useState("");
  const [installType, setInstallType] = useState("");
  const [meterStatus, setMeterStatus] = useState("");
  const [needPlanDoc, setNeedPlanDoc] = useState("");
  const [surveyResult, setSurveyResult] = useState("");
  const [propertyAllow, setPropertyAllow] = useState("");
  /* 任务R 表单预设字段：线缆规格（保存进 SurveyInfo，不进话术模板） */
  const [cableSpec, setCableSpec] = useState("");
  /** 增项下拉的受控选中值（选中追加一行后立即复位，便于连续添加） */
  const [addonPick, setAddonPick] = useState("");
  /* 任务v33：零跑增项模板下拉选中值（同 addonPick 口径，选中追加后立即复位） */
  const [leapPick, setLeapPick] = useState("");

  /* 打开时初始化：默认今天 / 勘测人联动设置页工程师姓名 /
   * 一键带入品牌物料包 / 6 项读表单预设（设置页「表单预设」区可改） */
  useEffect(() => {
    if (!open || !order) return;
    setErrors({});
    setScriptOpen(false);
    setEstimatePreviewOpen(false); // 任务v35：打开/换单时复位预估清单预览层
    setSurveyDate(todayStr());
    setSurveyor(settings.engineerName ?? "");
    setCableDistance("30");
    setNote("");
    /* 任务v35：套包米数预填——已持久化值 → 原文识别 → 空串（识别不到可手填） */
    const pmText =
      order.packageMeters != null
        ? String(order.packageMeters)
        : String(parsePackageMetersFromText(order.originalText ?? "") ?? "");
    setPackageMetersInput(pmText);
    /* 任务v35：品牌物料包带出后，按打开初始距离同步「线缆敷设」增项行
     * （与 v29 完工弹窗同节奏：仅打开初始化 + 米数变更时调用，两次变更之间手改不调） */
    const rateCfg = loadRateConfigs().find((r) => r.brandId === order.brandId);
    const initPm =
      Number(pmText) ||
      parsePackageMetersFromText(order.originalText ?? "") ||
      (rateCfg?.packageMeters ?? FALLBACK_PACKAGE_METERS);
    const initOverPrice =
      rateCfg?.overMeterPrice ?? FALLBACK_OVER_METER_PRICE;
    setMaterials(getBrandMaterialPack(order.brandId));
    setMaterials((prev) =>
      syncCableAddonRow(prev, 30, initPm, initOverPrice),
    );
    const presets = loadFormPresets();
    setPowerSource(presets.powerSource);
    setCableSpec(presets.cableSpec);
    setInstallType(presets.installType);
    setMeterStatus(presets.meterStatus);
    setNeedPlanDoc(presets.needPlanDoc);
    setSurveyResult(presets.surveyResult);
    setPropertyAllow("");
    setAddonPick("");
    setLeapPick(""); // 任务v33：打开/order 变化时复位零跑模板下拉
  }, [open, order, settings.engineerName]);

  /* 品牌名解析：order.brandId 经 findBrand/mergeBrands 解析为 v7 口径品牌名 */
  const brandName = useMemo(() => {
    if (!order) return "";
    return findBrand(order.brandId, customBrands)?.name ?? order.brandId;
  }, [order, customBrands]);

  /* 任务v33 零跑触发判定：品牌名解析与 AppContext 同口径
   * （mergeBrands 合并内置+自定义品牌按 id 查名，未命中回退 brandId） */
  const leapmotorBrandName =
    mergeBrands(customBrands).find((b) => b.id === order?.brandId)?.name ??
    order?.brandId ??
    "";
  const leapmotorActive = order ? isLeapmotorBrand(leapmotorBrandName) : false;

  /* 任务v33 零跑增项模板选项：仅零跑单加载（设置页可改价/增删，缺省默认36条） */
  const leapmotorTemplates = useMemo(
    () => (leapmotorActive ? loadLeapmotorAddons() : []),
    [leapmotorActive],
  );

  /* 增项下拉选项：品牌增项清单按历史使用频率降序（排序由 getAddonOptions 保证） */
  const addonOptions = useMemo(
    () => (order ? getAddonOptions(brandName, orders) : []),
    [order, brandName, orders],
  );

  /* 该品牌套包米数/超米单价：读设置页「费率配置」，未配置回退缺省常量 */
  const rateConfig = useMemo(
    () =>
      order
        ? loadRateConfigs().find((r) => r.brandId === order.brandId)
        : undefined,
    [order],
  );
  const packageMeters = rateConfig?.packageMeters ?? FALLBACK_PACKAGE_METERS;
  const overMeterPrice = rateConfig?.overMeterPrice ?? FALLBACK_OVER_METER_PRICE;

  /* 电缆距离 → 预估增项：(距离-套包米数)>0 才显示；(距离-套包)×超米单价 */
  const distanceNum = Number(cableDistance);
  const overMeters = Number.isFinite(distanceNum)
    ? Math.round((distanceNum - packageMeters) * 100) / 100
    : 0;
  const overEstimateFee =
    overMeters > 0 ? Math.round(overMeters * overMeterPrice * 100) / 100 : 0;

  const validate = (): boolean => {
    const next: SurveyErrors = {};
    if (!surveyDate) next.surveyDate = "请选择勘测日期";
    if (!surveyor.trim()) next.surveyor = "请填写勘测人";
    const distance = Number(cableDistance);
    if (!Number.isFinite(distance) || distance <= 0)
      next.cableDistance = "请填写正确的距离（米）";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  /* 任务v35：布线总距离变更 → 同步「线缆敷设」增项行（与 v29 完工弹窗同节奏：
   * 只在米数变化时调用；手调该行金额后行保留，再次改动米数才按最新值重算覆盖）。
   * 套包值取数链：手填/预填 packageMetersInput → 原文识别 → 品牌费率 packageMeters 兜底 */
  const handleCableDistanceChange = (value: string) => {
    setCableDistance(value);
    if (!order) return;
    const pm =
      Number(packageMetersInput) ||
      parsePackageMetersFromText(order.originalText ?? "") ||
      packageMeters;
    const trimmed = value.trim();
    const parsed = trimmed === "" ? undefined : Number(trimmed);
    setMaterials((prev) =>
      syncCableAddonRow(
        prev,
        parsed != null && Number.isFinite(parsed) ? parsed : undefined,
        pm,
        overMeterPrice,
      ),
    );
  };

  /* ---- 增项区行编辑（勘测表单自实现，与导出的 MaterialListEditor 无关） ---- */
  const patchMaterial = (
    index: number,
    key: keyof MaterialItem,
    value: string,
  ) => {
    const next = materials.map((item, i) => {
      if (i !== index) return item;
      if (key === "quantity") {
        const num = Number(value);
        return { ...item, quantity: Number.isFinite(num) ? num : 0 };
      }
      if (key === "unitPrice") {
        /* 金额清空 → 回到套包内行（无单价，话术只列"名称 数量"不计价） */
        if (value.trim() === "") {
          const cleared = { ...item };
          delete cleared.unitPrice;
          return cleared;
        }
        const num = Number(value);
        return { ...item, unitPrice: Number.isFinite(num) ? num : 0 };
      }
      return { ...item, [key]: value };
    });
    setMaterials(next);
  };

  const removeMaterial = (index: number) => {
    setMaterials(materials.filter((_, i) => i !== index));
  };

  /* 下拉选中增项：追加一行（数量 1、金额=材料库出售单价，金额可改），随后复位下拉 */
  const addAddon = (name: string) => {
    setAddonPick("");
    const option = addonOptions.find((o) => o.name === name);
    if (!option) return;
    setMaterials((prev) => [
      ...prev,
      {
        name: option.name,
        spec: "",
        quantity: 1,
        unit: option.unit,
        unitPrice: option.salePrice,
      },
    ]);
  };

  /* 生成预估清单文本（任务v35：「线缆敷设」行带单价时按超出计费格式输出，
   * 总距离=当前布线距离；其余行保持「{i+1}. 名称 规格 ×数量单位」一字不动） */
  const buildEstimateText = (): string => {
    if (!order) return "";
    const validMaterials = materials.filter((m) => m.name.trim() !== "");
    const materialLines = validMaterials.map((m, i) => {
      if (m.name.trim() === CABLE_ADDON_ROW_NAME && m.unitPrice != null) {
        return buildCableOverFeeText(
          Number(cableDistance) || 0,
          m.quantity,
          m.unitPrice,
        );
      }
      const spec = m.spec.trim();
      return `${i + 1}. ${m.name.trim()}${spec ? ` ${spec}` : ""} ×${m.quantity}${m.unit}`;
    });
    return [
      "【充电桩安装预估清单】",
      `客户：${order.customerName}`,
      `地址：${order.address}`,
      `电表到桩位距离：${cableDistance}米`,
      "物料明细：",
      materialLines.length > 0 ? materialLines.join("\n") : "按现场勘测确定",
      `备注：${note.trim()}`,
    ].join("\n");
  };

  /* 预估清单预览「复制」回调：复制编辑后文本（clipboard API + execCommand 兜底） */
  const handleEstimateCopy = async (edited: string) => {
    try {
      await navigator.clipboard.writeText(edited);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = edited;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    showToast("预估清单已复制，可粘贴发给客户");
    setEstimatePreviewOpen(false);
  };

  /* 真正提交（话术弹窗"复制并继续"或无模板跳过时调用） */
  const handleConfirmSubmit = () => {
    if (!order || !validate()) return;
    /* 任务v35：套包米数为有限数且>0 → 先持久化到 order.packageMeters；
     * 空/非法则不写（不拦截，原提交流程照走） */
    const pm = Number(packageMetersInput);
    if (Number.isFinite(pm) && pm > 0) {
      updateOrder(order.id, { ...order, packageMeters: pm });
    }
    // 过滤掉名称为空的物料行
    const validMaterials = materials.filter((m) => m.name.trim() !== "");
    saveSurvey(order.id, {
      surveyDate,
      surveyor: surveyor.trim(),
      cableDistance: Number(cableDistance),
      note: note.trim(),
      materials: validMaterials,
      powerSource: powerSource.trim(),
      installType: installType.trim(),
      meterStatus,
      needPlanDoc,
      surveyResult: surveyResult.trim(),
      propertyAllow,
      cableSpec: cableSpec.trim(),
    });
    showToast("勘测已登记，订单进入「已勘测」");
    onClose();
  };

  /* 点「保存勘测」：校验通过后先弹勘测完成话术；该品牌无模板则跳过直接提交 */
  const handleSubmit = () => {
    if (!order || !validate()) return;
    const template = getScript(
      order.brandId,
      "surveyComplete",
      loadBrandScripts(),
    );
    if (!template) {
      handleConfirmSubmit();
      return;
    }
    setScriptOpen(true);
  };

  /* 话术变量：有效物料逐行「名称 规格 ×数量单位」，无物料按现场勘测确定；
   * 任务v35：「线缆敷设」行带单价时换 buildCableOverFeeText（总距离=当前布线距离），
   * 其余行自拼格式一字不动 */
  const scriptMaterials = materials.filter((m) => m.name.trim() !== "");
  const materialsText =
    scriptMaterials.length > 0
      ? scriptMaterials
          .map((m) => {
            if (m.name.trim() === CABLE_ADDON_ROW_NAME && m.unitPrice != null) {
              return buildCableOverFeeText(
                Number(cableDistance) || 0,
                m.quantity,
                m.unitPrice,
              );
            }
            const spec = m.spec.trim();
            return `${m.name.trim()}${spec ? ` ${spec}` : ""} ×${m.quantity}${m.unit}`;
          })
          .join("\n")
      : "按现场勘测确定";

  if (!order) return null;

  return (
    <>
    <Modal
      open={open}
      title={`登记勘测 · ${order.customerName}`}
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn--outline" onClick={onClose}>
            取消
          </button>
          <button
            type="button"
            className="btn btn--primary btn--lg"
            onClick={handleSubmit}
          >
            保存勘测
          </button>
        </>
      }
    >
      {/* ---- 分区卡片①：线缆信息（双列网格，标签在上控件在下） ---- */}
      <div className="card card--flat">
        <div className="card__title">线缆信息</div>
        <div className="form-grid-2col">
          <FormField
            label="电表到桩位距离（米）"
            required
            error={errors.cableDistance}
          >
            <input
              className={errors.cableDistance ? "input input--error" : "input"}
              type="number"
              inputMode="decimal"
              min="0"
              value={cableDistance}
              onChange={(e) => handleCableDistanceChange(e.target.value)}
            />
          </FormField>

          {/* 任务v35：套包米数（打开预填持久化值/原文识别值，识别不到可手填；
              保存时有值才写回 order.packageMeters） */}
          <FormField label="套包米数">
            <input
              className="input"
              type="number"
              inputMode="decimal"
              min="0"
              placeholder="未识别可手填，如 30"
              value={packageMetersInput}
              onChange={(e) => setPackageMetersInput(e.target.value)}
            />
          </FormField>

          <FormField label="线缆规格">
            <input
              className="input"
              value={cableSpec}
              placeholder="如 3*6"
              onChange={(e) => setCableSpec(e.target.value)}
            />
          </FormField>

          <FormField label="取电方式">
            <input
              className="input"
              value={powerSource}
              placeholder="如 国网取电"
              onChange={(e) => setPowerSource(e.target.value)}
            />
          </FormField>

          <FormField label="勘测详情">
            <input
              className="input"
              value={installType}
              placeholder="如 壁挂安装"
              onChange={(e) => setInstallType(e.target.value)}
            />
          </FormField>
        </div>
        {/* 距离超出套包米数时实时提示预估增项费用 */}
        {overEstimateFee > 0 ? (
          <p className="text-sm text-secondary mt-sm">
            预估增项{" "}
            <span className="text-bold">
              ¥{overEstimateFee}
            </span>
            （超{overMeters}m × {overMeterPrice}元/米）
          </p>
        ) : null}
      </div>

      {/* ---- 分区卡片②：位置信息（双列网格，标签在上控件在下） ---- */}
      <div className="card card--flat">
        <div className="card__title">位置信息</div>
        <div className="form-grid-2col">
          <FormField label="勘测日期" required error={errors.surveyDate}>
            <input
              className="input"
              type="date"
              value={surveyDate}
              onChange={(e) => setSurveyDate(e.target.value)}
            />
          </FormField>

          <FormField label="勘测人" required error={errors.surveyor}>
            <input
              className={errors.surveyor ? "input input--error" : "input"}
              value={surveyor}
              placeholder="可在设置页工程师信息配置"
              onChange={(e) => setSurveyor(e.target.value)}
            />
          </FormField>

          <FormField label="电表状态">
            <select
              className="input"
              value={meterStatus}
              onChange={(e) => setMeterStatus(e.target.value)}
            >
              <option value="">未选择</option>
              <option value="已安装">已安装</option>
              <option value="未安装">未安装</option>
            </select>
          </FormField>

          <FormField label="物业需要施工方案图">
            <select
              className="input"
              value={needPlanDoc}
              onChange={(e) => setNeedPlanDoc(e.target.value)}
            >
              <option value="">未选择</option>
              <option value="是">是</option>
              <option value="否">否</option>
            </select>
          </FormField>

          <FormField label="物业是否允许施工">
            <select
              className="input"
              value={propertyAllow}
              onChange={(e) => setPropertyAllow(e.target.value)}
            >
              <option value="">未选择</option>
              <option value="是">是</option>
              <option value="否">否</option>
            </select>
          </FormField>

          <FormField label="勘测结果">
            <input
              className="input"
              value={surveyResult}
              placeholder="如 车位是符合安装"
              onChange={(e) => setSurveyResult(e.target.value)}
            />
          </FormField>
        </div>
      </div>

      {/* ---- 增项物料：下拉选择（该品牌清单按历史频率降序），
           选中带出售单价为默认金额，可增可删可改金额 ---- */}
      <FormField label="增项物料">
        <div className="flex-column gap-sm">
          {materials.map((item, index) => (
            <div key={index} className="card card--flat">
              <div className="flex gap-sm">
                <input
                  className="input flex-1"
                  placeholder="物料名称"
                  value={item.name}
                  onChange={(e) => patchMaterial(index, "name", e.target.value)}
                />
                {/* 任务v33 零跑单行金额（仅零跑单渲染；无单价=套包内不计价） */}
                {leapmotorActive && (
                  <span className="text-sm text-secondary">
                    {item.unitPrice !== undefined
                      ? `¥${leapmotorAddonLineAmount(item.unitPrice, item.quantity)}`
                      : "套包内"}
                  </span>
                )}
                <button
                  type="button"
                  className="btn btn--danger-outline btn--sm"
                  aria-label="删除物料"
                  onClick={() => removeMaterial(index)}
                >
                  删
                </button>
              </div>
              <div className="flex gap-sm mt-sm">
                <input
                  className="input flex-1"
                  placeholder="规格"
                  value={item.spec}
                  onChange={(e) => patchMaterial(index, "spec", e.target.value)}
                />
                <input
                  className="input flex-1"
                  type="number"
                  inputMode="decimal"
                  min="0"
                  placeholder="数量"
                  value={String(item.quantity)}
                  onChange={(e) =>
                    patchMaterial(index, "quantity", e.target.value)
                  }
                />
                <input
                  className="input flex-1"
                  placeholder="单位"
                  value={item.unit}
                  onChange={(e) => patchMaterial(index, "unit", e.target.value)}
                />
                <input
                  className="input flex-1"
                  type="number"
                  inputMode="decimal"
                  min="0"
                  placeholder="金额(元)"
                  value={item.unitPrice != null ? String(item.unitPrice) : ""}
                  onChange={(e) =>
                    patchMaterial(index, "unitPrice", e.target.value)
                  }
                />
              </div>
            </div>
          ))}
          {/* 任务v33 零跑增项模板下拉（仅零跑单渲染，位于现有品牌增项下拉上方）：
              选中带出名称/单位/单价追加一行（数量默认1，行内可改），随后复位 */}
          {leapmotorActive && (
            <select
              className="input"
              value={leapPick}
              aria-label="从零跑增项模板选择添加"
              onChange={(e) => {
                const t = leapmotorTemplates.find(
                  (x) => x.id === e.target.value,
                );
                setLeapPick("");
                if (!t) return;
                setMaterials((prev) => [
                  ...prev,
                  {
                    name: t.name,
                    spec: "",
                    quantity: 1,
                    unit: t.unit,
                    unitPrice: t.price,
                  },
                ]);
              }}
            >
              <option value="">从零跑模板选择添加…</option>
              {leapmotorTemplates.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}（{t.price}元/{t.unit}）
                </option>
              ))}
            </select>
          )}
          <select
            className="input"
            value={addonPick}
            aria-label="选择增项加入清单"
            onChange={(e) => addAddon(e.target.value)}
          >
            <option value="">＋ 选择增项（按常用排序）…</option>
            {addonOptions.map((option) => (
              <option key={option.name} value={option.name}>
                {option.name}（{option.unit}）¥{option.salePrice}
                {option.usageCount > 0 ? ` · 用过${option.usageCount}次` : ""}
              </option>
            ))}
          </select>
          {/* 任务v33 零跑增项区底合计（仅零跑单渲染；只对带单价行计价） */}
          {leapmotorActive && (
            <div className="text-sm text-secondary">
              增项合计 ¥{leapmotorAddonsTotal(materials)}
            </div>
          )}
        </div>
      </FormField>

      {/* 任务v35：外发文本先弹预览（可复制前编辑），不再直复制 */}
      <button
        type="button"
        className="btn btn--secondary btn--sm"
        onClick={() => setEstimatePreviewOpen(true)}
      >
        生成预估清单预览
      </button>

      <FormField label="勘测备注">
        <textarea
          className="textarea"
          value={note}
          placeholder="走线路径、施工难点、物业要求等"
          onChange={(e) => setNote(e.target.value)}
        />
      </FormField>
    </Modal>

    {/* 勘测完成话术：复制后继续提交；onClose 仅关话术层，保留勘测表单 */}
    <ScriptDialog
      open={scriptOpen}
      order={order}
      scene="surveyComplete"
      extras={{
        materialsText,
        totalCostText: "以实际为准",
        installerName: surveyor.trim(),
        cableDistance: Number(cableDistance),
        surveyDate,
        surveyNote: note.trim(),
        powerSource: powerSource.trim(),
        installType: installType.trim(),
        meterStatus,
        needPlanDoc,
        surveyResult: surveyResult.trim(),
        propertyAllow,
        materials: scriptMaterials,
      }}
      onClose={() => setScriptOpen(false)}
      onConfirm={handleConfirmSubmit}
    />

    {/* 任务v35：预估清单外发预览（打开即载入最新文本，编辑后复制） */}
    <TextPreviewDialog
      open={estimatePreviewOpen}
      title="预估清单预览"
      text={buildEstimateText()}
      onClose={() => setEstimatePreviewOpen(false)}
      onCopy={handleEstimateCopy}
    />
    </>
  );
}
