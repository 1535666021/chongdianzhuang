/* ============================================================
 * 勘测登记弹窗
 * 内含并导出 MaterialListEditor（勘测/完工两个弹窗共用物料编辑器，
 * 遵守"≥2次抽公共"规则，同时不新增锁定目录之外的文件）
 * ============================================================ */

import { useEffect, useMemo, useState } from "react";
import { Modal } from "@/components/common/Modal";
import { FormField } from "@/components/common/FormField";
import { ScriptDialog } from "@/components/ScriptDialog";
import { useApp } from "@/context/AppContext";
import { getBrandMaterialPack } from "@/lib/brandMaterials";
import { getScript } from "@/lib/scripts";
import { loadBrandScripts, loadCostMappings, loadMaterialsLib } from "@/lib/storage";
import { materialNames } from "@/lib/materials";
import { todayStr } from "@/lib/utils";
import type { MaterialItem, SurveyModalProps } from "@/types";

/* ------------------------------------------------------------
 * 物料清单编辑器（导出供 CompleteModal 复用）
 * ------------------------------------------------------------ */
export interface MaterialListEditorProps {
  items: MaterialItem[];
  onChange: (items: MaterialItem[]) => void;
}

const EMPTY_MATERIAL: MaterialItem = {
  name: "",
  spec: "",
  quantity: 1,
  unit: "个",
};

export function MaterialListEditor({ items, onChange }: MaterialListEditorProps) {
  const { orders } = useApp();

  /* 增项名称联想：按历史订单物料使用频率降序（同频保持映射表原顺序）。
   * 仅提供候选，选中后不回填 unitPrice（单价是客户价，由师傅定） */
  const nameOptions = useMemo(() => {
    const freq = new Map<string, number>();
    for (const order of orders) {
      const used = [
        ...(order.survey?.materials ?? []),
        ...(order.completion?.materials ?? []),
      ];
      for (const m of used) {
        freq.set(m.name, (freq.get(m.name) ?? 0) + 1);
      }
    }
    const fromMappings = loadCostMappings().map((m) => m.addonName);
    /* 任务D：候选 = 成本映射增项 ∪ 材料库名称（去重），按使用频率降序、同频按来源顺序 */
    const fromLib = materialNames(loadMaterialsLib());
    const all = [...new Set([...fromMappings, ...fromLib])];
    return all
      .map((name, index) => ({ name, index, count: freq.get(name) ?? 0 }))
      .sort((a, b) => b.count - a.count || a.index - b.index)
      .map((entry) => entry.name);
  }, [orders]);

  const patchItem = (
    index: number,
    key: keyof MaterialItem,
    value: string,
  ) => {
    const next = items.map((item, i) => {
      if (i !== index) return item;
      if (key === "quantity" || key === "unitPrice") {
        const num = Number(value);
        return { ...item, [key]: Number.isFinite(num) ? num : 0 };
      }
      return { ...item, [key]: value };
    });
    onChange(next);
  };

  const removeItem = (index: number) => {
    onChange(items.filter((_, i) => i !== index));
  };

  const addItem = () => {
    onChange([...items, { ...EMPTY_MATERIAL }]);
  };

  return (
    <div className="flex-column gap-sm">
      {/* 增项候选（按使用频率降序），勘测/完工两弹窗共用此 datalist */}
      <datalist id="material-name-options">
        {nameOptions.map((name) => (
          <option key={name} value={name} />
        ))}
      </datalist>
      {items.map((item, index) => (
        <div key={index} className="card card--flat">
          <div className="flex gap-sm">
            <input
              className="input flex-1"
              placeholder="物料名称"
              list="material-name-options"
              value={item.name}
              onChange={(e) => patchItem(index, "name", e.target.value)}
            />
            <button
              type="button"
              className="btn btn--danger-outline btn--sm"
              aria-label="删除物料"
              onClick={() => removeItem(index)}
            >
              删
            </button>
          </div>
          <div className="flex gap-sm mt-sm">
            <input
              className="input flex-1"
              placeholder="规格"
              value={item.spec}
              onChange={(e) => patchItem(index, "spec", e.target.value)}
            />
            <input
              className="input flex-1"
              type="number"
              inputMode="decimal"
              min="0"
              placeholder="数量"
              value={String(item.quantity)}
              onChange={(e) => patchItem(index, "quantity", e.target.value)}
            />
            <input
              className="input flex-1"
              placeholder="单位"
              value={item.unit}
              onChange={(e) => patchItem(index, "unit", e.target.value)}
            />
          </div>
        </div>
      ))}
      <button
        type="button"
        className="btn btn--secondary btn--sm"
        onClick={addItem}
      >
        ＋ 添加物料
      </button>
    </div>
  );
}

/* ------------------------------------------------------------
 * 勘测弹窗主体
 * ------------------------------------------------------------ */
interface SurveyErrors {
  surveyDate?: string;
  surveyor?: string;
  cableDistance?: string;
}

export function SurveyModal({ open, order, onClose }: SurveyModalProps) {
  const { settings, saveSurvey, showToast } = useApp();

  const [surveyDate, setSurveyDate] = useState(todayStr());
  const [surveyor, setSurveyor] = useState("");
  const [cableDistance, setCableDistance] = useState("30");
  const [note, setNote] = useState("");
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [errors, setErrors] = useState<SurveyErrors>({});
  /** 勘测完成话术弹窗开关（保存勘测校验通过后先弹话术） */
  const [scriptOpen, setScriptOpen] = useState(false);
  /* 任务Q 话术变量可选字段（不强制填写，缺省话术对应变量为空） */
  const [powerSource, setPowerSource] = useState("");
  const [installType, setInstallType] = useState("");
  const [meterStatus, setMeterStatus] = useState("");
  const [needPlanDoc, setNeedPlanDoc] = useState("");
  const [surveyResult, setSurveyResult] = useState("");
  const [propertyAllow, setPropertyAllow] = useState("");

  /* 打开时初始化：默认今天 / 默认勘测人 / 一键带入品牌物料包 */
  useEffect(() => {
    if (!open || !order) return;
    setErrors({});
    setScriptOpen(false);
    setSurveyDate(todayStr());
    setSurveyor(settings.defaultSurveyor);
    setCableDistance("30");
    setNote("");
    setMaterials(getBrandMaterialPack(order.brandId));
    setPowerSource("");
    setInstallType("");
    setMeterStatus("");
    setNeedPlanDoc("");
    setSurveyResult("");
    setPropertyAllow("");
  }, [open, order, settings.defaultSurveyor]);

  const validate = (): boolean => {
    const next: SurveyErrors = {};
    if (!surveyDate) next.surveyDate = "请选择勘测日期";
    if (!surveyor.trim()) next.surveyor = "请填写勘测人";
    const distance = Number(cableDistance);
    if (!Number.isFinite(distance) || distance <= 0)
      next.cableDistance = "请填写正确的距离（米）";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  /* 生成预估清单文本并复制到剪贴板（clipboard API + execCommand 兜底） */
  const handleCopyEstimate = async () => {
    if (!order) return;
    const validMaterials = materials.filter((m) => m.name.trim() !== "");
    const materialLines = validMaterials.map((m, i) => {
      const spec = m.spec.trim();
      return `${i + 1}. ${m.name.trim()}${spec ? ` ${spec}` : ""} ×${m.quantity}${m.unit}`;
    });
    const text = [
      "【充电桩安装预估清单】",
      `客户：${order.customerName}`,
      `地址：${order.address}`,
      `电表到桩位距离：${cableDistance}米`,
      "物料明细：",
      materialLines.length > 0 ? materialLines.join("\n") : "按现场勘测确定",
      `备注：${note.trim()}`,
    ].join("\n");
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    showToast("预估清单已复制，可粘贴发给客户");
  };

  /* 真正提交（话术弹窗"复制并继续"或无模板跳过时调用） */
  const handleConfirmSubmit = () => {
    if (!order || !validate()) return;
    // 过滤掉名称为空的物料行
    const validMaterials = materials.filter((m) => m.name.trim() !== "");
    saveSurvey(order.id, {
      surveyDate,
      surveyor: surveyor.trim(),
      cableDistance: Number(cableDistance),
      note: note.trim(),
      materials: validMaterials,
      powerSource: powerSource.trim(),
      installType: installType.trim(),
      meterStatus,
      needPlanDoc,
      surveyResult: surveyResult.trim(),
      propertyAllow,
    });
    showToast("勘测已登记，订单进入「已勘测」");
    onClose();
  };

  /* 点「保存勘测」：校验通过后先弹勘测完成话术；该品牌无模板则跳过直接提交 */
  const handleSubmit = () => {
    if (!order || !validate()) return;
    const template = getScript(
      order.brandId,
      "surveyComplete",
      loadBrandScripts(),
    );
    if (!template) {
      handleConfirmSubmit();
      return;
    }
    setScriptOpen(true);
  };

  /* 话术变量：有效物料逐行「名称 规格 ×数量单位」，无物料按现场勘测确定 */
  const scriptMaterials = materials.filter((m) => m.name.trim() !== "");
  const materialsText =
    scriptMaterials.length > 0
      ? scriptMaterials
          .map((m) => {
            const spec = m.spec.trim();
            return `${m.name.trim()}${spec ? ` ${spec}` : ""} ×${m.quantity}${m.unit}`;
          })
          .join("\n")
      : "按现场勘测确定";

  if (!order) return null;

  return (
    <>
    <Modal
      open={open}
      title={`登记勘测 · ${order.customerName}`}
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn--outline" onClick={onClose}>
            取消
          </button>
          <button
            type="button"
            className="btn btn--primary btn--lg"
            onClick={handleSubmit}
          >
            保存勘测
          </button>
        </>
      }
    >
      <FormField label="勘测日期" required error={errors.surveyDate}>
        <input
          className="input"
          type="date"
          value={surveyDate}
          onChange={(e) => setSurveyDate(e.target.value)}
        />
      </FormField>

      <FormField label="勘测人" required error={errors.surveyor}>
        <input
          className={errors.surveyor ? "input input--error" : "input"}
          value={surveyor}
          placeholder="可在设置页配置默认勘测人"
          onChange={(e) => setSurveyor(e.target.value)}
        />
      </FormField>

      <FormField label="电表到桩位距离（米）" required error={errors.cableDistance}>
        <input
          className={errors.cableDistance ? "input input--error" : "input"}
          type="number"
          inputMode="decimal"
          min="0"
          value={cableDistance}
          onChange={(e) => setCableDistance(e.target.value)}
        />
      </FormField>

      {/* 任务Q 话术变量可选字段：不强制，填了话术自动代入 */}
      <FormField label="用电方式/电源点性质（话术用，可选）">
        <input
          className="input"
          value={powerSource}
          placeholder="如 居民用电 / 商业用电"
          onChange={(e) => setPowerSource(e.target.value)}
        />
      </FormField>

      <FormField label="安装方式/勘测详情（话术用，可选）">
        <input
          className="input"
          value={installType}
          placeholder="如 壁挂式 7kW 交流桩"
          onChange={(e) => setInstallType(e.target.value)}
        />
      </FormField>

      <FormField label="电表状态（话术条件用，可选）">
        <select
          className="input"
          value={meterStatus}
          onChange={(e) => setMeterStatus(e.target.value)}
        >
          <option value="">未选择</option>
          <option value="已安装">已安装</option>
          <option value="未安装">未安装</option>
        </select>
      </FormField>

      <FormField label="物业需要施工方案图（可选）">
        <select
          className="input"
          value={needPlanDoc}
          onChange={(e) => setNeedPlanDoc(e.target.value)}
        >
          <option value="">未选择</option>
          <option value="是">是</option>
          <option value="否">否</option>
        </select>
      </FormField>

      <FormField label="物业是否允许施工（可选）">
        <select
          className="input"
          value={propertyAllow}
          onChange={(e) => setPropertyAllow(e.target.value)}
        >
          <option value="">未选择</option>
          <option value="是">是</option>
          <option value="否">否</option>
        </select>
      </FormField>

      <FormField label="勘测结果（可选）">
        <input
          className="input"
          value={surveyResult}
          placeholder="如 具备安装条件"
          onChange={(e) => setSurveyResult(e.target.value)}
        />
      </FormField>

      <FormField label="勘测物料清单">
        <MaterialListEditor items={materials} onChange={setMaterials} />
      </FormField>

      <button
        type="button"
        className="btn btn--secondary btn--sm"
        onClick={handleCopyEstimate}
      >
        复制预估清单发客户
      </button>

      <FormField label="勘测备注">
        <textarea
          className="textarea"
          value={note}
          placeholder="走线路径、施工难点、物业要求等"
          onChange={(e) => setNote(e.target.value)}
        />
      </FormField>
    </Modal>

    {/* 勘测完成话术：复制后继续提交；onClose 仅关话术层，保留勘测表单 */}
    <ScriptDialog
      open={scriptOpen}
      order={order}
      scene="surveyComplete"
      extras={{
        materialsText,
        totalCostText: "以实际为准",
        installerName: surveyor.trim(),
        cableDistance: Number(cableDistance),
        surveyDate,
        surveyNote: note.trim(),
        powerSource: powerSource.trim(),
        installType: installType.trim(),
        meterStatus,
        needPlanDoc,
        surveyResult: surveyResult.trim(),
        propertyAllow,
        materials: scriptMaterials,
      }}
      onClose={() => setScriptOpen(false)}
      onConfirm={handleConfirmSubmit}
    />
    </>
  );
}
