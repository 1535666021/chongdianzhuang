/* ============================================================
 * 完工登记弹窗
 * 默认带出：预约的安装师傅、勘测物料清单（可改为实际用量）
 * 物料编辑器复用 SurveyModal 导出的 MaterialListEditor
 * 成本核算：复用 finance.calcOrderProfit，随物料/扣点率实时预估到手利润
 * ============================================================ */

import { useEffect, useMemo, useState } from "react";
import { Modal } from "@/components/common/Modal";
import { FormField } from "@/components/common/FormField";
import { MaterialListEditor } from "@/components/modals/SurveyModal";
import { ScriptDialog } from "@/components/ScriptDialog";
import { useApp } from "@/context/AppContext";
import { calcOrderProfit, DEFAULT_RATE_CONFIG } from "@/lib/finance";
import type { OrderProfitResult } from "@/lib/finance";
import { getScript } from "@/lib/scripts";
import {
  loadBrandScripts,
  loadCostMappings,
  loadPlatformRates,
  loadPlatforms,
  loadRateConfigs,
} from "@/lib/storage";
import { formatMoney, todayStr } from "@/lib/utils";
import type { CompleteModalProps, MaterialItem, Order } from "@/types";

interface CompleteErrors {
  completeDate?: string;
  installer?: string;
  workHours?: string;
}

/** 扣点率小数 → 百分比文本（0.1 → "10"，0.075 → "7.5"，避免浮点长尾） */
function rateToPercentText(rate: number): string {
  return String(Number((rate * 100).toFixed(2)));
}

/** 订单适用的平台默认扣点率（jd / other） */
function getPlatformDefaultRate(order: Order): number {
  const rates = loadPlatformRates();
  return order.platformType === "jd" ? rates.jd : rates.other;
}

/**
 * 对比勘测物料与实际物料，生成修改记录：
 * 数量变化「电缆 30→35米」/ 新增「+ 打孔 ×2」/ 删除「- PVC管」
 */
function buildMaterialChangeRecords(
  before: MaterialItem[],
  after: MaterialItem[],
): string[] {
  const records: string[] = [];
  const afterMap = new Map(after.map((m) => [m.name.trim(), m]));
  const beforeKeys = new Set(before.map((m) => m.name.trim()));
  const afterKeys = new Set(after.map((m) => m.name.trim()));
  // 数量变化（按勘测清单顺序）
  for (const old of before) {
    const cur = afterMap.get(old.name.trim());
    if (cur && cur.quantity !== old.quantity) {
      records.push(
        `${cur.name.trim()} ${old.quantity}→${cur.quantity}${cur.unit || old.unit}`,
      );
    }
  }
  // 新增（按实际清单顺序）
  for (const cur of after) {
    if (!beforeKeys.has(cur.name.trim())) {
      records.push(`+ ${cur.name.trim()} ×${cur.quantity}`);
    }
  }
  // 删除（按勘测清单顺序）
  for (const old of before) {
    if (!afterKeys.has(old.name.trim())) {
      records.push(`- ${old.name.trim()}`);
    }
  }
  return records;
}

export function CompleteModal({ open, order, onClose }: CompleteModalProps) {
  const { settings, saveCompletion, showToast } = useApp();

  const [completeDate, setCompleteDate] = useState(todayStr());
  const [installer, setInstaller] = useState("");
  const [workHours, setWorkHours] = useState("2");
  const [note, setNote] = useState("");
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [errors, setErrors] = useState<CompleteErrors>({});
  /** 扣点率输入框（百分比文本，如 "10" 表示 10%） */
  const [rateInput, setRateInput] = useState("");
  /** 扣点率覆盖值（小数）；undefined = 按平台默认扣点 */
  const [rateOverride, setRateOverride] = useState<number | undefined>(
    undefined,
  );
  /** 安装完工话术弹窗开关（保存完工校验通过后先弹话术） */
  const [scriptOpen, setScriptOpen] = useState(false);

  /* 打开时初始化：默认今天 / 预约师傅或默认师傅 / 勘测物料带出 / 扣点率覆盖重置为空 */
  useEffect(() => {
    if (!open || !order) return;
    setErrors({});
    setScriptOpen(false);
    setCompleteDate(todayStr());
    setInstaller(order.appointment?.installer || settings.defaultInstaller);
    setWorkHours("2");
    setNote("");
    setMaterials(
      (order.survey?.materials ?? []).map((item) => ({ ...item })),
    );
    setRateOverride(undefined);
    setRateInput(rateToPercentText(getPlatformDefaultRate(order)));
  }, [open, order, settings.defaultInstaller]);

  /* 成本自动计算 + 利润实时预览：随物料清单 / 扣点率覆盖实时重算 */
  const profitResult = useMemo<OrderProfitResult | null>(() => {
    if (!open || !order) return null;
    const rateConfig = loadRateConfigs().find(
      (c) => c.brandId === order.brandId,
    ) ?? { brandId: order.brandId, ...DEFAULT_RATE_CONFIG };
    return calcOrderProfit({
      order,
      materials: materials.filter((m) => m.name.trim() !== ""),
      rateConfig,
      platformRates: loadPlatformRates(),
      platforms: loadPlatforms(),
      mappings: loadCostMappings(),
      platformRateOverride: rateOverride,
    });
  }, [open, order, materials, rateOverride]);

  /* 重新核算：输入百分比 ÷100 作为扣点率覆盖；输入为空则恢复平台默认 */
  const handleRecalc = () => {
    if (!order) return;
    const trimmed = rateInput.trim();
    if (trimmed === "") {
      setRateOverride(undefined);
      setRateInput(rateToPercentText(getPlatformDefaultRate(order)));
      return;
    }
    const percent = Number(trimmed);
    if (!Number.isFinite(percent) || percent < 0 || percent > 100) return;
    setRateOverride(percent / 100);
  };

  const validate = (): boolean => {
    const next: CompleteErrors = {};
    if (!completeDate) next.completeDate = "请选择完工日期";
    if (!installer.trim()) next.installer = "请填写安装师傅";
    const hours = Number(workHours);
    if (!Number.isFinite(hours) || hours <= 0)
      next.workHours = "请填写正确的工时（小时）";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  /* 真正提交（话术弹窗"复制并继续"或无模板跳过时调用） */
  const handleConfirmSubmit = () => {
    if (!order || !validate()) return;
    const validMaterials = materials.filter((m) => m.name.trim() !== "");
    // 修改记录：对比勘测物料与实际物料（数量变化 / 新增 / 删除），有变更时拼到备注末尾
    const changeRecords = buildMaterialChangeRecords(
      order.survey?.materials ?? [],
      validMaterials,
    );
    const baseNote = note.trim();
    const finalNote =
      changeRecords.length > 0
        ? `${baseNote ? `${baseNote}\n` : ""}【修改记录】${changeRecords.join("；")}`
        : baseNote;
    saveCompletion(order.id, {
      completeDate,
      installer: installer.trim(),
      materials: validMaterials,
      workHours: Number(workHours),
      note: finalNote,
      /* 新完工单利润快照双写：平台扣点 + 结算费/增项/材料/利润四项，
       * 统计三级链第二级取数（v7 老单快照在 legacyProfit，此处禁碰） */
      ...(profitResult
        ? {
            platformDeduction: profitResult.platformDeduction,
            profitData: {
              baseFee: profitResult.serviceFee,
              customerPaid: profitResult.customerAddonFee,
              materialCost: profitResult.materialCost,
              profit: profitResult.profit,
            },
          }
        : {}),
    });
    showToast("完工已登记，订单进入「已完成」");
    onClose();
  };

  /* 点「保存完工」：校验通过后先弹安装完工话术；该品牌无模板则跳过直接提交 */
  const handleSubmit = () => {
    if (!order || !validate()) return;
    const template = getScript(
      order.brandId,
      "installComplete",
      loadBrandScripts(),
    );
    if (!template) {
      handleConfirmSubmit();
      return;
    }
    setScriptOpen(true);
  };

  /* 话术变量：实际物料逐行「名称 规格 ×数量单位」/ 预估到手金额 / 安装师傅 */
  const scriptMaterials = materials.filter((m) => m.name.trim() !== "");
  const materialsText =
    scriptMaterials.length > 0
      ? scriptMaterials
          .map((m) => {
            const spec = m.spec.trim();
            return `${m.name.trim()}${spec ? ` ${spec}` : ""} ×${m.quantity}${m.unit}`;
          })
          .join("\n")
      : "按现场勘测确定";

  if (!order) return null;

  return (
    <>
    <Modal
      open={open}
      title={`登记完工 · ${order.customerName}`}
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn--outline" onClick={onClose}>
            取消
          </button>
          <button
            type="button"
            className="btn btn--primary btn--lg"
            onClick={handleSubmit}
          >
            保存完工
          </button>
        </>
      }
    >
      <FormField label="完工日期" required error={errors.completeDate}>
        <input
          className="input"
          type="date"
          value={completeDate}
          onChange={(e) => setCompleteDate(e.target.value)}
        />
      </FormField>

      <FormField label="安装师傅" required error={errors.installer}>
        <input
          className={errors.installer ? "input input--error" : "input"}
          value={installer}
          placeholder="默认带出预约师傅，可修改"
          onChange={(e) => setInstaller(e.target.value)}
        />
      </FormField>

      <FormField label="实际工时（小时）" required error={errors.workHours}>
        <input
          className={errors.workHours ? "input input--error" : "input"}
          type="number"
          inputMode="decimal"
          min="0"
          step="0.5"
          value={workHours}
          onChange={(e) => setWorkHours(e.target.value)}
        />
      </FormField>

      <FormField label="实际使用物料（默认带出勘测清单，可按实际修改）">
        <MaterialListEditor items={materials} onChange={setMaterials} />
      </FormField>

      {profitResult && (
        <div className="card card--flat mt-sm">
          <div className="flex-column gap-sm">
            <div className="text-sm text-bold">成本核算</div>
            <div className="flex-between text-sm">
              <span className="text-secondary">客户增项费</span>
              <span>{formatMoney(profitResult.customerAddonFee)}</span>
            </div>
            <div className="flex-between text-sm">
              <span className="text-secondary">
                平台扣点（{rateToPercentText(profitResult.platformRate)}%）
              </span>
              <span>
                - {formatMoney(Math.abs(profitResult.platformDeduction))}
              </span>
            </div>
            <div className="flex-between text-sm">
              <span className="text-secondary">材料成本（含固定辅材）</span>
              <span>- {formatMoney(Math.abs(profitResult.materialCost))}</span>
            </div>
            <div className="flex-between text-sm">
              <span className="text-secondary">服务费（按服务类型）</span>
              <span>+ {formatMoney(profitResult.serviceFee)}</span>
            </div>
            <div className="flex-between">
              <span className="text-sm text-bold">预估到手</span>
              <span className="text-lg text-bold text-primary-color">
                {formatMoney(profitResult.profit)}
              </span>
            </div>
            {profitResult.unmappedMaterials.length > 0 && (
              <div className="text-sm text-secondary">
                以下材料未配置成本映射，成本按0计：
                {profitResult.unmappedMaterials.join("、")}
              </div>
            )}
            <div className="flex-column gap-xs">
              <span className="text-sm text-secondary">
                扣点率（%，清空后点重新核算恢复平台默认）
              </span>
              <div className="flex gap-sm">
                <input
                  className="input flex-1"
                  type="number"
                  inputMode="decimal"
                  min="0"
                  max="100"
                  step="0.1"
                  value={rateInput}
                  onChange={(e) => setRateInput(e.target.value)}
                />
                <button
                  type="button"
                  className="btn btn--secondary btn--sm"
                  onClick={handleRecalc}
                >
                  重新核算
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <FormField label="完工备注">
        <textarea
          className="textarea"
          value={note}
          placeholder="验收情况、遗留事项等"
          onChange={(e) => setNote(e.target.value)}
        />
      </FormField>
    </Modal>

    {/* 安装完工话术：复制后继续提交；onClose 仅关话术层，保留完工表单 */}
    <ScriptDialog
      open={scriptOpen}
      order={order}
      scene="installComplete"
      extras={{
        materialsText,
        totalCostText: profitResult
          ? formatMoney(profitResult.profit)
          : "以实际为准",
        installerName: installer.trim(),
      }}
      onClose={() => setScriptOpen(false)}
      onConfirm={handleConfirmSubmit}
    />
    </>
  );
}
