/* ============================================================
 * 完工登记弹窗（任务R2 改造）
 * 勘测数据贯通：打开即预填——完工日期=当天 / 安装师傅=预约师傅或默认师傅 /
 *   实际用线=勘测米数 / 增项物料=勘测物料带出 / 完工备注=勘测备注带出 /
 *   安装详情=勘测安装方式（回退表单预设）；电源点/安装方式等勘测字段经
 *   buildScriptVars 从 order.survey 回退进入话术（extras 无需再传）
 * 增项下拉：与勘测页同一 getAddonOptions（契约§4，禁两份逻辑），
 *   选中带 salePrice 默认金额，行内可改；每行可改、可删
 * 超米费联动（任务v35 换芯）：实际用线变化 → lib/packageMeters.syncCableAddonRow
 *   生成/更新/移除「线缆敷设」增项行（(实际用线-套包米数)×超米单价，≤0 不出现；
 *   手调该行金额后，再改米数才按最新值重算覆盖）；
 *   套包米数=resolveOrderPackageMeters(order)（持久化值→原文识别，
 *   打开时识别到即 updateOrder 写回持久化） ?? 品牌费率 packageMeters；
 *   超米单价读 loadRateConfigs()（缺省 45 元·米），不硬编码
 * 平台扣点后台化：表单不再录入扣点率，利润直接按 loadPlatformRates()/platforms
 *   后台配置核算；profitData 快照字段与口径不变（统计不受影响）
 * ============================================================ */

import { useEffect, useMemo, useState } from "react";
import { Modal } from "@/components/common/Modal";
import { FormField } from "@/components/common/FormField";
import { ScriptDialog } from "@/components/ScriptDialog";
import { useApp } from "@/context/AppContext";
import { getAddonOptions } from "@/lib/addonOptions";
import { findBrand, mergeBrands } from "@/lib/brandMaterials";
import { calcOrderProfit, DEFAULT_RATE_CONFIG } from "@/lib/finance";
import type { OrderProfitResult } from "@/lib/finance";
/* 任务v33：零跑增项触发判定与金额计算（业务逻辑收敛 lib，本组件只渲染） */
import {
  isLeapmotorBrand,
  leapmotorAddonLineAmount,
  leapmotorAddonsTotal,
} from "@/lib/leapmotorAddons";
/* 任务v35：「超米费」行换芯为「线缆敷设」行（业务逻辑收敛 lib/packageMeters） */
import {
  buildCableOverFeeText,
  CABLE_ADDON_ROW_NAME,
  resolveOrderPackageMeters,
  syncCableAddonRow,
} from "@/lib/packageMeters";
import { getScript } from "@/lib/scripts";
import {
  loadBrandScripts,
  loadCostMappings,
  loadFormPresets,
  loadLeapmotorAddons,
  loadPlatformRates,
  loadPlatforms,
  loadRateConfigs,
} from "@/lib/storage";
import { formatMoney, todayStr } from "@/lib/utils";
import type { CompleteModalProps, MaterialItem } from "@/types";

interface CompleteErrors {
  completeDate?: string;
  installer?: string;
  workHours?: string;
}

/** 扣点率小数 → 百分比文本（0.1 → "10"，0.075 → "7.5"，避免浮点长尾） */
function rateToPercentText(rate: number): string {
  return String(Number((rate * 100).toFixed(2)));
}

/**
 * 超米单价缺省值（元/米）：品牌费率未配置 overMeterPrice 时的兜底，
 * 与 types 注释 / scripts.ts 话术计费口径一致（缺省 45 元/米）
 */
const DEFAULT_OVER_METER_PRICE = 45;

/**
 * 本单品牌套包米数/超米单价：读 loadRateConfigs()（禁硬编码业务值），
 * 无品牌配置或字段缺省时回退 30 米 / 45 元·米
 */
function getBrandOverRate(brandId: string): {
  packageMeters: number;
  overMeterPrice: number;
} {
  const config = loadRateConfigs().find((c) => c.brandId === brandId);
  return {
    packageMeters: config?.packageMeters ?? DEFAULT_RATE_CONFIG.packageMeters,
    overMeterPrice: config?.overMeterPrice ?? DEFAULT_OVER_METER_PRICE,
  };
}

/**
 * 对比勘测物料与实际物料，生成修改记录：
 * 数量变化「电缆 30→35米」/ 新增「+ 打孔 ×2」/ 删除「- PVC管」
 */
function buildMaterialChangeRecords(
  before: MaterialItem[],
  after: MaterialItem[],
): string[] {
  const records: string[] = [];
  const afterMap = new Map(after.map((m) => [m.name.trim(), m]));
  const beforeKeys = new Set(before.map((m) => m.name.trim()));
  const afterKeys = new Set(after.map((m) => m.name.trim()));
  // 数量变化（按勘测清单顺序）
  for (const old of before) {
    const cur = afterMap.get(old.name.trim());
    if (cur && cur.quantity !== old.quantity) {
      records.push(
        `${cur.name.trim()} ${old.quantity}→${cur.quantity}${cur.unit || old.unit}`,
      );
    }
  }
  // 新增（按实际清单顺序）
  for (const cur of after) {
    if (!beforeKeys.has(cur.name.trim())) {
      records.push(`+ ${cur.name.trim()} ×${cur.quantity}`);
    }
  }
  // 删除（按勘测清单顺序）
  for (const old of before) {
    if (!afterKeys.has(old.name.trim())) {
      records.push(`- ${old.name.trim()}`);
    }
  }
  return records;
}

export function CompleteModal({ open, order, onClose }: CompleteModalProps) {
  const { settings, orders, customBrands, saveCompletion, showToast, updateOrder } =
    useApp();

  const [completeDate, setCompleteDate] = useState(todayStr());
  const [installer, setInstaller] = useState("");
  const [workHours, setWorkHours] = useState("2");
  const [note, setNote] = useState("");
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [errors, setErrors] = useState<CompleteErrors>({});
  /** 安装完工话术弹窗开关（保存完工校验通过后先弹话术） */
  const [scriptOpen, setScriptOpen] = useState(false);
  /** 增项下拉当前选中值（选中追加行后复位，与勘测页同口径） */
  const [addonPick, setAddonPick] = useState("");
  /* 任务v33：零跑增项模板下拉选中值（同 addonPick 口径，选中追加后立即复位） */
  const [leapPick, setLeapPick] = useState("");

  /* 任务Q 话术变量可选字段（不强制；缺省话术对应变量为空/回退勘测值） */
  const [actualCable, setActualCable] = useState("");
  const [addonFee, setAddonFee] = useState("");
  const [installDetail, setInstallDetail] = useState("");

  /* 打开时初始化（勘测数据贯通预填）：
   * 完工日期=当天 / 安装师傅=预约师傅或默认师傅 / 工时默认 2 /
   * 实际用线=勘测米数（并据此同步「超米费」增项行）/ 增项物料=勘测物料带出 /
   * 完工备注=勘测备注带出（师傅可改）/ 安装详情=勘测安装方式（回退表单预设） */
  useEffect(() => {
    if (!open || !order) return;
    setErrors({});
    setScriptOpen(false);
    setAddonPick("");
    setLeapPick(""); // 任务v33：打开/order 变化时复位零跑模板下拉
    setCompleteDate(todayStr());
    setInstaller(order.appointment?.installer || settings.defaultInstaller);
    setWorkHours("2");
    setNote(order.survey?.note ?? "");
    const cable = order.survey?.cableDistance;
    setActualCable(cable != null ? String(cable) : "");
    /* 任务v35：套包米数未持久化且原文可识别 → 打开即写回持久化（识别依据见 lib/packageMeters） */
    const resolvedPm = resolveOrderPackageMeters(order);
    if (order.packageMeters == null && resolvedPm != null) {
      updateOrder(order.id, { ...order, packageMeters: resolvedPm });
    }
    const { packageMeters, overMeterPrice } = getBrandOverRate(order.brandId);
    setMaterials(
      syncCableAddonRow(
        (order.survey?.materials ?? []).map((item) => ({ ...item })),
        cable,
        resolvedPm ?? packageMeters,
        overMeterPrice,
      ),
    );
    setAddonFee("");
    setInstallDetail(
      order.survey?.installType?.trim()
        ? order.survey.installType
        : loadFormPresets().installType,
    );
  }, [open, order, settings.defaultInstaller]);

  /* 成本自动计算 + 利润实时预览：随物料清单实时重算。
   * 平台扣点后台化：不传 platformRateOverride，
   * 扣点率直接取 loadPlatformRates()/platforms 后台配置 */
  const profitResult = useMemo<OrderProfitResult | null>(() => {
    if (!open || !order) return null;
    const rateConfig = loadRateConfigs().find(
      (c) => c.brandId === order.brandId,
    ) ?? { brandId: order.brandId, ...DEFAULT_RATE_CONFIG };
    return calcOrderProfit({
      order,
      materials: materials.filter((m) => m.name.trim() !== ""),
      rateConfig,
      platformRates: loadPlatformRates(),
      platforms: loadPlatforms(),
      mappings: loadCostMappings(),
    });
  }, [open, order, materials]);

  /* 增项下拉选项：与勘测页同一 getAddonOptions（契约§4，禁两份逻辑）；
   * 品牌名解析与 ScriptDialog 同口径（内置品牌 id → 品牌名，自定义品牌直接用名） */
  const addonOptions = useMemo(() => {
    if (!open || !order) return [];
    const brandName =
      findBrand(order.brandId, customBrands)?.name ?? order.brandId;
    return getAddonOptions(brandName, orders);
  }, [open, order, orders, customBrands]);

  /* 任务v33 零跑触发判定：品牌名解析与 AppContext 同口径
   * （mergeBrands 合并内置+自定义品牌按 id 查名，未命中回退 brandId） */
  const leapmotorBrandName =
    mergeBrands(customBrands).find((b) => b.id === order?.brandId)?.name ??
    order?.brandId ??
    "";
  const leapmotorActive = order ? isLeapmotorBrand(leapmotorBrandName) : false;

  /* 任务v33 零跑增项模板选项：仅零跑单加载（设置页可改价/增删，缺省默认36条） */
  const leapmotorTemplates = useMemo(
    () => (leapmotorActive ? loadLeapmotorAddons() : []),
    [leapmotorActive],
  );

  /* 增项行编辑：每行可改可删（与勘测页增项区同口径；
   * 金额清空 → 删除 unitPrice 回到不计价行，非法数字按 0 收） */
  const patchMaterial = (
    index: number,
    key: keyof MaterialItem,
    value: string,
  ) => {
    setMaterials((prev) =>
      prev.map((item, i) => {
        if (i !== index) return item;
        if (key === "quantity") {
          const num = Number(value);
          return { ...item, quantity: Number.isFinite(num) ? num : 0 };
        }
        if (key === "unitPrice") {
          if (value.trim() === "") {
            const cleared = { ...item };
            delete cleared.unitPrice;
            return cleared;
          }
          const num = Number(value);
          return { ...item, unitPrice: Number.isFinite(num) ? num : 0 };
        }
        return { ...item, [key]: value };
      }),
    );
  };

  const removeMaterial = (index: number) => {
    setMaterials((prev) => prev.filter((_, i) => i !== index));
  };

  /* 增项下拉选中：追加一行（数量 1、金额=材料库出售单价，金额可改），随后复位下拉 */
  const addAddon = (name: string) => {
    setAddonPick("");
    const option = addonOptions.find((o) => o.name === name);
    if (!option) return;
    setMaterials((prev) => [
      ...prev,
      {
        name: option.name,
        spec: "",
        quantity: 1,
        unit: option.unit,
        unitPrice: option.salePrice,
      },
    ]);
  };

  /* 实际用线变更：同步「线缆敷设」增项行（纯函数收敛 lib/packageMeters，组件只调用）。
   * 只在米数变化时调用：手调该行金额后行保留，再次改动米数才按最新值重算覆盖 */
  const handleActualCableChange = (value: string) => {
    setActualCable(value);
    if (!order) return;
    const { packageMeters, overMeterPrice } = getBrandOverRate(order.brandId);
    const pm = resolveOrderPackageMeters(order) ?? packageMeters;
    const trimmed = value.trim();
    const parsed = trimmed === "" ? undefined : Number(trimmed);
    setMaterials((prev) =>
      syncCableAddonRow(
        prev,
        parsed != null && Number.isFinite(parsed) ? parsed : undefined,
        pm,
        overMeterPrice,
      ),
    );
  };

  const validate = (): boolean => {
    const next: CompleteErrors = {};
    if (!completeDate) next.completeDate = "请选择完工日期";
    if (!installer.trim()) next.installer = "请填写安装师傅";
    const hours = Number(workHours);
    if (!Number.isFinite(hours) || hours <= 0)
      next.workHours = "请填写正确的工时（小时）";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  /* 真正提交（话术弹窗"复制并继续"或无模板跳过时调用） */
  const handleConfirmSubmit = () => {
    if (!order || !validate()) return;
    const validMaterials = materials.filter((m) => m.name.trim() !== "");
    // 修改记录：对比勘测物料与实际物料（数量变化 / 新增 / 删除），有变更时拼到备注末尾
    const changeRecords = buildMaterialChangeRecords(
      order.survey?.materials ?? [],
      validMaterials,
    );
    const baseNote = note.trim();
    const finalNote =
      changeRecords.length > 0
        ? `${baseNote ? `${baseNote}\n` : ""}【修改记录】${changeRecords.join("；")}`
        : baseNote;
    saveCompletion(order.id, {
      completeDate,
      installer: installer.trim(),
      materials: validMaterials,
      workHours: Number(workHours),
      note: finalNote,
      /* 任务Q 话术变量字段（可选，空串不入库） */
      ...(actualCable.trim() !== "" && Number.isFinite(Number(actualCable))
        ? { actualCable: Number(actualCable) }
        : {}),
      ...(addonFee.trim() !== "" && Number.isFinite(Number(addonFee))
        ? { addonFee: Number(addonFee) }
        : {}),
      ...(installDetail.trim() !== ""
        ? { installDetail: installDetail.trim() }
        : {}),
      /* 新完工单利润快照双写：平台扣点 + 结算费/增项/材料/利润四项，
       * 统计三级链第二级取数（v7 老单快照在 legacyProfit，此处禁碰） */
      ...(profitResult
        ? {
            platformDeduction: profitResult.platformDeduction,
            profitData: {
              baseFee: profitResult.serviceFee,
              customerPaid: profitResult.customerAddonFee,
              materialCost: profitResult.materialCost,
              profit: profitResult.profit,
            },
          }
        : {}),
    });
    showToast("完工已登记，订单进入「已完成」");
    onClose();
  };

  /* 点「保存完工」：校验通过后先弹安装完工话术；该品牌无模板则跳过直接提交 */
  const handleSubmit = () => {
    if (!order || !validate()) return;
    const template = getScript(
      order.brandId,
      "installComplete",
      loadBrandScripts(),
    );
    if (!template) {
      handleConfirmSubmit();
      return;
    }
    setScriptOpen(true);
  };

  /* 话术变量：实际物料逐行「名称 规格 ×数量单位」/ 预估到手金额 / 安装师傅；
   * 任务v35：「线缆敷设」行带单价时换 buildCableOverFeeText（总距离=实际用线
   * ?? 勘测米数，与 buildScriptVars 同口径），其余行自拼格式一字不动 */
  const scriptMaterials = materials.filter((m) => m.name.trim() !== "");
  const materialsText =
    scriptMaterials.length > 0
      ? scriptMaterials
          .map((m) => {
            if (m.name.trim() === CABLE_ADDON_ROW_NAME && m.unitPrice != null) {
              return buildCableOverFeeText(
                Number(actualCable) ||
                  Number(order?.survey?.cableDistance) ||
                  0,
                m.quantity,
                m.unitPrice,
              );
            }
            const spec = m.spec.trim();
            return `${m.name.trim()}${spec ? ` ${spec}` : ""} ×${m.quantity}${m.unit}`;
          })
          .join("\n")
      : "按现场勘测确定";

  if (!order) return null;

  return (
    <>
    <Modal
      open={open}
      title={`登记完工 · ${order.customerName}`}
      onClose={onClose}
      footer={
        <>
          <button type="button" className="btn btn--outline" onClick={onClose}>
            取消
          </button>
          <button
            type="button"
            className="btn btn--primary btn--lg"
            onClick={handleSubmit}
          >
            保存完工
          </button>
        </>
      }
    >
      <FormField label="完工日期" required error={errors.completeDate}>
        <input
          className="input"
          type="date"
          value={completeDate}
          onChange={(e) => setCompleteDate(e.target.value)}
        />
      </FormField>

      <FormField label="安装师傅" required error={errors.installer}>
        <input
          className={errors.installer ? "input input--error" : "input"}
          value={installer}
          placeholder="默认带出预约师傅，可修改"
          onChange={(e) => setInstaller(e.target.value)}
        />
      </FormField>

      <FormField label="实际工时（小时）" required error={errors.workHours}>
        <input
          className={errors.workHours ? "input input--error" : "input"}
          type="number"
          inputMode="decimal"
          min="0"
          step="0.5"
          value={workHours}
          onChange={(e) => setWorkHours(e.target.value)}
        />
      </FormField>

      {/* ---- 增项物料：默认带出勘测清单与超米费行；下拉选择（与勘测页同一
             getAddonOptions），选中带出售单价为默认金额，可增可删可改金额 ---- */}
      <FormField label="实际使用物料（默认带出勘测清单与线缆敷设行，每行可改可删）">
        <div className="flex-column gap-sm">
          {materials.map((item, index) => (
            <div key={index} className="card card--flat">
              <div className="flex gap-sm">
                <input
                  className="input flex-1"
                  placeholder="物料名称"
                  value={item.name}
                  onChange={(e) => patchMaterial(index, "name", e.target.value)}
                />
                {/* 任务v33 零跑单行金额（仅零跑单渲染；无单价=套包内不计价） */}
                {leapmotorActive && (
                  <span className="text-sm text-secondary">
                    {item.unitPrice !== undefined
                      ? `¥${leapmotorAddonLineAmount(item.unitPrice, item.quantity)}`
                      : "套包内"}
                  </span>
                )}
                <button
                  type="button"
                  className="btn btn--danger-outline btn--sm"
                  aria-label="删除物料"
                  onClick={() => removeMaterial(index)}
                >
                  删
                </button>
              </div>
              <div className="flex gap-sm mt-sm">
                <input
                  className="input flex-1"
                  placeholder="规格"
                  value={item.spec}
                  onChange={(e) => patchMaterial(index, "spec", e.target.value)}
                />
                <input
                  className="input flex-1"
                  type="number"
                  inputMode="decimal"
                  min="0"
                  placeholder="数量"
                  value={String(item.quantity)}
                  onChange={(e) =>
                    patchMaterial(index, "quantity", e.target.value)
                  }
                />
                <input
                  className="input flex-1"
                  placeholder="单位"
                  value={item.unit}
                  onChange={(e) => patchMaterial(index, "unit", e.target.value)}
                />
                <input
                  className="input flex-1"
                  type="number"
                  inputMode="decimal"
                  min="0"
                  placeholder="金额(元)"
                  value={item.unitPrice != null ? String(item.unitPrice) : ""}
                  onChange={(e) =>
                    patchMaterial(index, "unitPrice", e.target.value)
                  }
                />
              </div>
            </div>
          ))}
          {/* 任务v33 零跑增项模板下拉（仅零跑单渲染，位于现有品牌增项下拉上方）：
              选中带出名称/单位/单价追加一行（数量默认1，行内可改），随后复位 */}
          {leapmotorActive && (
            <select
              className="input"
              value={leapPick}
              aria-label="从零跑增项模板选择添加"
              onChange={(e) => {
                const t = leapmotorTemplates.find(
                  (x) => x.id === e.target.value,
                );
                setLeapPick("");
                if (!t) return;
                setMaterials((prev) => [
                  ...prev,
                  {
                    name: t.name,
                    spec: "",
                    quantity: 1,
                    unit: t.unit,
                    unitPrice: t.price,
                  },
                ]);
              }}
            >
              <option value="">从零跑模板选择添加…</option>
              {leapmotorTemplates.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}（{t.price}元/{t.unit}）
                </option>
              ))}
            </select>
          )}
          {/* 增项下拉：与勘测页完全一致（同一 getAddonOptions、同一交互），
              选中即追加一行并带默认金额，随后复位 */}
          <select
            className="input"
            value={addonPick}
            aria-label="选择增项加入清单"
            onChange={(e) => addAddon(e.target.value)}
          >
            <option value="">＋ 选择增项（按常用排序）…</option>
            {addonOptions.map((option) => (
              <option key={option.name} value={option.name}>
                {option.name}（{option.unit}）¥{option.salePrice}
                {option.usageCount > 0 ? ` · 用过${option.usageCount}次` : ""}
              </option>
            ))}
          </select>
          {/* 任务v33 零跑增项区底合计（仅零跑单渲染；只对带单价行计价） */}
          {leapmotorActive && (
            <div className="text-sm text-secondary">
              增项合计 ¥{leapmotorAddonsTotal(materials)}
            </div>
          )}
        </div>
      </FormField>

      {profitResult && (
        <div className="card card--flat mt-sm">
          <div className="flex-column gap-sm">
            <div className="text-sm text-bold">成本核算</div>
            <div className="flex-between text-sm">
              <span className="text-secondary">客户增项费</span>
              <span>{formatMoney(profitResult.customerAddonFee)}</span>
            </div>
            <div className="flex-between text-sm">
              <span className="text-secondary">
                平台扣点（{rateToPercentText(profitResult.platformRate)}%）
              </span>
              <span>
                - {formatMoney(Math.abs(profitResult.platformDeduction))}
              </span>
            </div>
            <div className="flex-between text-sm">
              <span className="text-secondary">材料成本（含固定辅材）</span>
              <span>- {formatMoney(Math.abs(profitResult.materialCost))}</span>
            </div>
            <div className="flex-between text-sm">
              <span className="text-secondary">服务费（按服务类型）</span>
              <span>+ {formatMoney(profitResult.serviceFee)}</span>
            </div>
            <div className="flex-between">
              <span className="text-sm text-bold">预估到手</span>
              <span className="text-lg text-bold text-primary-color">
                {formatMoney(profitResult.profit)}
              </span>
            </div>
            {profitResult.unmappedMaterials.length > 0 && (
              <div className="text-sm text-secondary">
                以下材料未配置成本映射，成本按0计：
                {profitResult.unmappedMaterials.join("、")}
              </div>
            )}
          </div>
        </div>
      )}

      {/* 任务Q 话术变量可选字段：不强制，填了话术自动代入 */}
      <FormField label="实际线缆用量（米，默认带出勘测距离；改动自动联动线缆敷设行）">
        <input
          className="input"
          type="number"
          inputMode="decimal"
          min="0"
          value={actualCable}
          placeholder="默认带出勘测距离，按实际修改"
          onChange={(e) => handleActualCableChange(e.target.value)}
        />
      </FormField>

      <FormField label="增项费用（元，话术用，可选）">
        <input
          className="input"
          type="number"
          inputMode="decimal"
          min="0"
          value={addonFee}
          placeholder="客户增项付费合计"
          onChange={(e) => setAddonFee(e.target.value)}
        />
      </FormField>

      <FormField label="安装详情（默认带出勘测安装方式，可改）">
        <input
          className="input"
          value={installDetail}
          placeholder="如 壁挂安装，PVC管敷设"
          onChange={(e) => setInstallDetail(e.target.value)}
        />
      </FormField>

      <FormField label="完工备注（默认带出勘测备注，可改）">
        <textarea
          className="textarea"
          value={note}
          placeholder="验收情况、遗留事项等"
          onChange={(e) => setNote(e.target.value)}
        />
      </FormField>
    </Modal>

    {/* 安装完工话术：复制后继续提交；onClose 仅关话术层，保留完工表单。
     * 电源点/安装方式等勘测字段不在 extras 传值，
     * 由 buildScriptVars 从 order.survey 回退带入（链路已确认） */}
    <ScriptDialog
      open={scriptOpen}
      order={order}
      scene="installComplete"
      extras={{
        materialsText,
        totalCostText: profitResult
          ? formatMoney(profitResult.profit)
          : "以实际为准",
        installerName: installer.trim(),
        completeDate,
        installDetail: installDetail.trim(),
        addonFee:
          addonFee.trim() !== "" && Number.isFinite(Number(addonFee))
            ? Number(addonFee)
            : undefined,
        actualCable:
          actualCable.trim() !== "" && Number.isFinite(Number(actualCable))
            ? Number(actualCable)
            : undefined,
        materials: scriptMaterials,
      }}
      onClose={() => setScriptOpen(false)}
      onConfirm={handleConfirmSubmit}
    />
    </>
  );
}
