/* ============================================================
 * 客户话术弹窗（理想上门 / 勘测完成 / 安装完工 三场景复用）
 * 模板来源：设置页按品牌+场景配置（storage.loadBrandScripts → scripts.getScript）
 * 复制：clipboard API + execCommand 兜底（同 OrderCard 写法）
 * ============================================================ */

import { useEffect, useState } from "react";
import { Modal } from "@/components/common/Modal";
import { FormField } from "@/components/common/FormField";
import { EmptyState } from "@/components/common/EmptyState";
import { Icon } from "@/components/common/Icon";
import { useApp } from "@/context/AppContext";
import {
  renderScript,
  buildScriptVars,
  getScript,
  SCRIPT_SCENES,
} from "@/lib/scripts";
import { loadBrandScripts } from "@/lib/storage";
import type { Order, ScriptScene } from "@/types";

export interface ScriptDialogProps {
  open: boolean;
  order: Order | null;
  scene: ScriptScene;
  /** 话术变量补充（物料明细文本/费用文本/师傅名），由触发方计算后传入 */
  extras?: {
    materialsText?: string;
    totalCostText?: string;
    installerName?: string;
    cableDistance?: number;
  };
  onClose: () => void;
  /** 点"复制并继续"时先复制话术再回调（用于继续原提交流程） */
  onConfirm?: () => void;
}

export function ScriptDialog({
  open,
  order,
  scene,
  extras,
  onClose,
  onConfirm,
}: ScriptDialogProps) {
  const { showToast } = useApp();
  /** 渲染后话术文本；空字符串 = 该品牌该场景未配置模板 */
  const [scriptText, setScriptText] = useState("");

  /* 拆成原始值做依赖，避免触发方每次渲染新建 extras 对象导致重复渲染 */
  const materialsText = extras?.materialsText;
  const totalCostText = extras?.totalCostText;
  const installerName = extras?.installerName;
  const cableDistance = extras?.cableDistance;

  /* 打开时：加载品牌话术模板 → 渲染变量；无模板置空走空态 */
  useEffect(() => {
    if (!open || !order) return;
    const template = getScript(order.brandId, scene, loadBrandScripts());
    if (!template) {
      setScriptText("");
      return;
    }
    setScriptText(
      renderScript(
        template,
        buildScriptVars(order, {
          materialsText,
          totalCostText,
          installerName,
          cableDistance,
        }),
      ),
    );
  }, [open, order, scene, materialsText, totalCostText, installerName, cableDistance]);

  /* 复制话术：clipboard API + execCommand 兜底（同 OrderCard） */
  const copyScript = async () => {
    if (!scriptText) return;
    try {
      await navigator.clipboard.writeText(scriptText);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = scriptText;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    showToast("话术已复制");
  };

  /* 复制并继续：先复制话术，再回调原提交流程，最后关闭 */
  const handleConfirm = async () => {
    await copyScript();
    onConfirm?.();
    onClose();
  };

  if (!order) return null;

  const hasScript = scriptText !== "";
  const sceneLabel =
    SCRIPT_SCENES.find((s) => s.key === scene)?.label ?? scene;

  return (
    <Modal
      open={open}
      title={`客户话术 · ${sceneLabel} · ${order.customerName}`}
      onClose={onClose}
      footer={
        onConfirm ? (
          <>
            <button type="button" className="btn btn--outline" onClick={onClose}>
              取消
            </button>
            <button
              type="button"
              className="btn btn--primary btn--lg"
              onClick={handleConfirm}
            >
              复制并继续
            </button>
          </>
        ) : (
          <button
            type="button"
            className="btn btn--primary btn--lg"
            onClick={onClose}
          >
            关闭
          </button>
        )
      }
    >
      {hasScript ? (
        <FormField label="话术内容（全选复制后粘贴发给客户）">
          <textarea
            className="textarea"
            readOnly
            rows={8}
            value={scriptText}
          />
        </FormField>
      ) : (
        <EmptyState
          icon={<Icon name="file-text" size={48} />}
          text="该品牌暂无此场景话术，请到设置页配置"
        />
      )}
      <button
        type="button"
        className="btn btn--secondary"
        disabled={!hasScript}
        onClick={copyScript}
      >
        复制话术
      </button>
    </Modal>
  );
}
