/* ============================================================
 * 全局状态：AppContext
 * 规范：跨页面业务数据统一由本模块管理；
 *      组件/页面通过 useApp() 读写，不直接碰 storage / localStorage
 * ============================================================ */

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { ReactNode } from "react";
import {
  OrderStatus,
  DEFAULT_APP_SETTINGS,
} from "@/types";
import type {
  AppSettings,
  AppointmentInfo,
  ChargeBrand,
  CompletionInfo,
  Order,
  OrderDraft,
  SurveyInfo,
} from "@/types";
import {
  ensureDataVersion,
  loadCustomBrands,
  loadOrders,
  loadSettings,
  saveCustomBrands,
  saveOrders,
  saveSettings,
  loadInventory,
  saveInventory,
} from "@/lib/storage";
import { adjustStock } from "@/lib/inventory";
import { generateId, nowIso } from "@/lib/utils";
import { mergeBrands } from "@/lib/brandMaterials";

/* ------------------------------------------------------------
 * 一、Context 值类型（页面可用的全部状态与方法）
 * ------------------------------------------------------------ */
export interface AppContextValue {
  /* ---- 数据 ---- */
  orders: Order[];
  settings: AppSettings;
  customBrands: ChargeBrand[];
  /** 内置 + 自定义 合并后的品牌列表（页面统一用这个） */
  brands: ChargeBrand[];
  /** 是否已完成首次加载（避免首屏闪空列表） */
  hydrated: boolean;

  /* ---- 订单操作 ---- */
  addOrder: (draft: OrderDraft) => Order;
  updateOrder: (id: string, draft: OrderDraft) => void;
  deleteOrder: (id: string) => void;
  cancelOrder: (id: string) => void;
  /** 回收站：恢复订单（读 legacyExtra.status 还原原状态，无效值回退 待勘测），清除 deletedAt */
  restoreOrder: (id: string) => void;
  /** 回收站：彻底删除（物理移除，不可恢复；软删走 deleteOrder） */
  purgeOrder: (id: string) => void;
  /** 过期未装回退到已勘测，清除预约信息 */
  revertToSurveyed: (id: string) => void;
  /** 登记勘测：写入勘测信息并流转到 已勘测 */
  saveSurvey: (id: string, survey: SurveyInfo) => void;
  /** 登记预约：写入预约信息并流转到 已预约 */
  saveAppointment: (id: string, appointment: AppointmentInfo) => void;
  /** 登记完工：写入完工信息并流转到 已完成 */
  saveCompletion: (id: string, completion: CompletionInfo) => void;
  /** xlsx 批量导入：追加到现有订单，返回导入条数 */
  importOrders: (orders: Order[]) => number;

  /* ---- 设置 / 品牌 ---- */
  updateSettings: (patch: Partial<AppSettings>) => void;
  addCustomBrand: (brand: ChargeBrand) => void;

  /* ---- 数据重置（设置页导入备份/清空后同步内存） ---- */
  replaceAllData: (
    orders: Order[],
    settings: AppSettings,
    customBrands: ChargeBrand[],
  ) => void;

  /* ---- 轻提示 ---- */
  toast: string | null;
  showToast: (message: string) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

/* ------------------------------------------------------------
 * 二、Provider
 * ------------------------------------------------------------ */
const TOAST_DURATION = 2200;

export function AppProvider({ children }: { children: ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([]);
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_APP_SETTINGS);
  const [customBrands, setCustomBrands] = useState<ChargeBrand[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<number | null>(null);

  /* ---- 首次加载：版本迁移 → 读 storage ---- */
  useEffect(() => {
    ensureDataVersion();
    setOrders(loadOrders());
    setSettings(loadSettings());
    setCustomBrands(loadCustomBrands());
    setHydrated(true);
  }, []);

  /* ---- 变更自动持久化（hydrated 后才写，避免首刷覆盖存储） ---- */
  useEffect(() => {
    if (hydrated) saveOrders(orders);
  }, [orders, hydrated]);

  useEffect(() => {
    if (hydrated) saveSettings(settings);
  }, [settings, hydrated]);

  useEffect(() => {
    if (hydrated) saveCustomBrands(customBrands);
  }, [customBrands, hydrated]);

  /* ---- Toast：全局单例，自动消失 ---- */
  const showToast = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current !== null) {
      window.clearTimeout(toastTimer.current);
    }
    toastTimer.current = window.setTimeout(() => {
      setToast(null);
      toastTimer.current = null;
    }, TOAST_DURATION);
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimer.current !== null) {
        window.clearTimeout(toastTimer.current);
      }
    };
  }, []);

  /* ---- 订单操作 ---- */

  const addOrder = useCallback((draft: OrderDraft): Order => {
    const now = nowIso();
    const order: Order = {
      ...draft,
      id: generateId(),
      createdAt: now,
      updatedAt: now,
    };
    setOrders((prev) => [order, ...prev]);
    return order;
  }, []);

  const updateOrder = useCallback((id: string, draft: OrderDraft) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === id ? { ...o, ...draft, updatedAt: nowIso() } : o,
      ),
    );
  }, []);

  /* 回收站机制：删除 = 软删（status→Trash + deletedAt 记录删除时间，
   * 原状态暂存 legacyExtra.status 供恢复还原；物理删除走 purgeOrder） */
  /* 任务E：桩库存钩子——带桩订单完工-1、完成单删除回库+1、恢复完成单-1。
   * legacyExtra.noPile===true 的不带桩单跳过；库存键按品牌名（StockItem.brand） */
  const adjustInventoryFor = useCallback(
    (order: Order | undefined, delta: number) => {
      if (!order || order.legacyExtra?.noPile === true) return;
      const brandName =
        mergeBrands(customBrands).find((b) => b.id === order.brandId)?.name ??
        order.brandId;
      saveInventory(adjustStock(brandName, delta, loadInventory()));
    },
    [customBrands],
  );

  const deleteOrder = useCallback((id: string) => {
    const target = orders.find((o) => o.id === id);
    if (target?.status === OrderStatus.Completed) {
      adjustInventoryFor(target, 1);
    }
    setOrders((prev) =>
      prev.map((o) =>
        o.id === id
          ? {
              ...o,
              status: OrderStatus.Trash,
              deletedAt: nowIso(),
              legacyExtra: { ...o.legacyExtra, status: o.status },
              updatedAt: nowIso(),
            }
          : o,
      ),
    );
  }, [orders, adjustInventoryFor]);

  const cancelOrder = useCallback((id: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === id
          ? { ...o, status: OrderStatus.Cancelled, updatedAt: nowIso() }
          : o,
      ),
    );
  }, []);

  const revertToSurveyed = useCallback((id: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === id
          ? {
              ...o,
              status: OrderStatus.Surveyed,
              appointment: undefined,
              updatedAt: nowIso(),
            }
          : o,
      ),
    );
  }, []);

  /* 回收站恢复：仅对 trash 单生效；原状态取自 legacyExtra.status
   * （迁移与软删时写入），缺失/非法值回退 待勘测，并清除 deletedAt */
  const restoreOrder = useCallback((id: string) => {
    const target = orders.find((o) => o.id === id);
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== id || o.status !== OrderStatus.Trash) return o;
        const raw = o.legacyExtra?.status;
        const restored =
          typeof raw === "string" &&
          raw !== OrderStatus.Trash &&
          (Object.values(OrderStatus) as string[]).includes(raw)
            ? (raw as OrderStatus)
            : OrderStatus.Pending;
        if (restored === OrderStatus.Completed) {
          adjustInventoryFor(target, -1);
        }
        return {
          ...o,
          status: restored,
          deletedAt: undefined,
          updatedAt: nowIso(),
        };
      }),
    );
  }, [orders, adjustInventoryFor]);

  /* 回收站彻底删除：物理移除，不可恢复 */
  const purgeOrder = useCallback((id: string) => {
    setOrders((prev) => prev.filter((o) => o.id !== id));
  }, []);

  const saveSurvey = useCallback((id: string, survey: SurveyInfo) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === id
          ? {
              ...o,
              survey,
              status: OrderStatus.Surveyed,
              updatedAt: nowIso(),
            }
          : o,
      ),
    );
  }, []);

  const saveAppointment = useCallback(
    (id: string, appointment: AppointmentInfo) => {
      setOrders((prev) =>
        prev.map((o) =>
          o.id === id
            ? {
                ...o,
                appointment,
                status: OrderStatus.Appointed,
                updatedAt: nowIso(),
              }
            : o,
        ),
      );
    },
    [],
  );

  const saveCompletion = useCallback(
    (id: string, completion: CompletionInfo) => {
      adjustInventoryFor(orders.find((o) => o.id === id), -1);
      setOrders((prev) =>
        prev.map((o) =>
          o.id === id
            ? {
                ...o,
                completion,
                status: OrderStatus.Completed,
                updatedAt: nowIso(),
              }
            : o,
        ),
      );
    },
    [orders, adjustInventoryFor],
  );

  const importOrders = useCallback((incoming: Order[]): number => {
    if (incoming.length === 0) return 0;
    setOrders((prev) => [...incoming, ...prev]);
    return incoming.length;
  }, []);

  /* ---- 设置 / 品牌 ---- */

  const updateSettings = useCallback((patch: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const addCustomBrand = useCallback((brand: ChargeBrand) => {
    setCustomBrands((prev) =>
      prev.some((b) => b.id === brand.id) ? prev : [...prev, brand],
    );
  }, []);

  /* ---- 数据重置（导入备份 / 清空后整体替换内存） ---- */
  const replaceAllData = useCallback(
    (
      nextOrders: Order[],
      nextSettings: AppSettings,
      nextBrands: ChargeBrand[],
    ) => {
      setOrders(nextOrders);
      setSettings(nextSettings);
      setCustomBrands(nextBrands);
    },
    [],
  );

  /* ---- 汇总 ---- */
  const brands = useMemo(() => mergeBrands(customBrands), [customBrands]);

  const value = useMemo<AppContextValue>(
    () => ({
      orders,
      settings,
      customBrands,
      brands,
      hydrated,
      addOrder,
      updateOrder,
      deleteOrder,
      cancelOrder,
      restoreOrder,
      purgeOrder,
      revertToSurveyed,
      saveSurvey,
      saveAppointment,
      saveCompletion,
      importOrders,
      updateSettings,
      addCustomBrand,
      replaceAllData,
      toast,
      showToast,
    }),
    [
      orders,
      settings,
      customBrands,
      brands,
      hydrated,
      addOrder,
      updateOrder,
      deleteOrder,
      cancelOrder,
      restoreOrder,
      purgeOrder,
      revertToSurveyed,
      saveSurvey,
      saveAppointment,
      saveCompletion,
      importOrders,
      updateSettings,
      addCustomBrand,
      replaceAllData,
      toast,
      showToast,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

/* ------------------------------------------------------------
 * 三、消费 Hook：页面/组件唯一取数入口
 * ------------------------------------------------------------ */
export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error("useApp 必须在 <AppProvider> 内使用");
  }
  return ctx;
}
